package com.retooling.batch.entity;

import java.util.List;

public class FarmProducts {
	private List<Egg> eggs;
	private List<Chicken> chickens;
	
	public FarmProducts() {
		super();
	}	
	
	public FarmProducts(List<Egg> eggs, List<Chicken> chickens) {
		super();
		this.eggs = eggs;
		this.chickens = chickens;
	}
	
	public List<Egg> getEggs() {
		return eggs;
	}
	
	public void setEggs(List<Egg> eggs) {
		this.eggs = eggs;
	}
	
	public List<Chicken> getChickens() {
		return chickens;
	}
	
	public void setChickens(List<Chicken> chickens) {
		this.chickens = chickens;
	}

	@Override
	public String toString() {
		return "FarmAnimals [eggs=" + eggs + ", chickens=" + chickens + "]";
	}
	
}
