package com.retooling.batch;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.entity.Chicken;
import com.retooling.batch.entity.Egg;
import com.retooling.batch.entity.FarmProducts;

public class ChangeReader implements ItemReader<FarmProducts> {

	private static final Logger logger = LoggerFactory.getLogger(ChangeReader.class);

	private RestTemplate restTemplate;
	private String urlEgg;
	private String urlChicken;
	boolean flag;
	
	public ChangeReader(RestTemplate restTemplate, String urlEgg, String urlChicken) {
		this.restTemplate = restTemplate;
		this.urlEgg = urlEgg;
		this.urlChicken = urlChicken;
		flag = false;
	}
	
	@Override
	public FarmProducts read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		
		if (flag == false) {
			FarmProducts fa = new FarmProducts();
			fa.setEggs(fetchEggDatafromAPI());
			fa.setChickens(fetchChickenDatafromAPI());
			flag = true;
			return fa;

		}
		flag = false;
		return null;
	}
	
	private List<Egg> fetchEggDatafromAPI() {
		logger.info("Reading data from Egg microservice...");
		EggState eggAvailable = EggState.Available;
		return Arrays.asList(restTemplate.getForObject(urlEgg, Egg[].class)).stream()
				.filter(e -> e.getState().equals(eggAvailable.getState())).collect(Collectors.toList());
	}

	private List<Chicken> fetchChickenDatafromAPI() {
		logger.info("Reading data from Chicken microservice...");
		ChickenState chickenAvailable = ChickenState.Available;
		return Arrays.asList(restTemplate.getForObject(urlChicken, Chicken[].class))
				.stream().filter(c -> c.getState().equals(chickenAvailable.getState())).collect(Collectors.toList());
	}

	
}
