package com.retooling.batch;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.retooling.batch.entity.Chicken;
import com.retooling.batch.entity.Egg;
import com.retooling.batch.entity.Farm;
import com.retooling.batch.entity.FarmProducts;

public class ChangeWriter implements ItemWriter<FarmProducts>{

	private static final Logger logger = LoggerFactory.getLogger(ChangeWriter.class);
	
	@Autowired
	private ApiCall apiCall;
	
	@Value("${batch.config.chicken-dead-days}") //90
	private int chickenDeadDays;	
	
	@Value("${batch.config.egg-to-chicken-days}") //60
	private int eggToChickensDays;
	
	@Value("${batch.config.days-amount-eggs}") //30
	private int daysAmountEggs;	
	
	@Value("${batch.config.eggs-amount-by-chicken}") //10
	private int eggsAmountByChicken;

	@Value("#{jobParameters['message']}")
	private long days;
	
	@Override
	public void write(Chunk<? extends FarmProducts> chunk) throws Exception {
		
		if (chunk.isEmpty()) {
			logger.info("No se encontraron productos de granja.");	
		} else {
			logger.info("Procesando productos de granja (pollos y huevos)...");
			
			Farm farm = apiCall.getFarm("1");
			
			logger.info("Valor de parámetro [days]: " + days);		
			
			//obtengo la fecha del sistema y le sumo la cantidad de dias
			//recibidos por parametro 
			Date currentDate = new Date();
			//String days = System.getProperty("days");
			//if (Integer.parseInt(days) < 0) {
			//	throw new Exception("El parámetro no puede ser menor a 0.");
			//}
			Calendar c = Calendar.getInstance();
			c.setTime(currentDate);
			//c.add(Calendar.DATE, Integer.valueOf(days));
			c.add(Calendar.DATE, (int) days);
			currentDate = c.getTime();
				
			FarmProducts fa = chunk.getItems().get(0); 
			
			List<Egg> eggs = fa.getEggs();
			int eggCountAvailable = eggs.size(); 
					
			List<Chicken> chickens = fa.getChickens();
			int chickenCountAvailable = chickens.size();
			
			logger.info("Cantidad de huevos disponibles ANTES del procesamiento: " + eggCountAvailable);
			logger.info("Cantidad de pollos disponibles ANTES del procesamiento: " + chickenCountAvailable);
			
			int chickensDead = 0;
			int eggsDiscarted = 0;
			int newEggsByChicken = 0;
			
			for(Chicken chicken : chickens){
				
				//double diffD = (double)((currentDate.getTime() - chicken.getCreationDate().getTime()) / 86400000);
				int diffDays = (int)((currentDate.getTime() - chicken.getCreationDate().getTime()) / 86400000);
				
				logger.info("Verificar pollos muertos...");
				//marcar pollo como muerto si corresponde
				if (diffDays >= chickenDeadDays) {
					ChickenState chickenDead = ChickenState.Dead;
					chicken.setState(chickenDead.getState());
					apiCall.updateChicken(chicken);
					logger.info("El pollo con id=[" + chicken.getChickenId() + "] se ha actualizado con estado '" + chickenDead.getState() + "'");
					chickensDead++;
				}
			
				//creo nuevos huevos si corresponde
				//obtengo la cantidad de dias entre la fecha actual y la fecha de la ultima vez que puso huevos
				//si esa cantidad supera la cantidad de dias que deben pasar para poner huevos, entonces
				//creo N cantidad de huevos nuevos, donde N es tambien una cantidad configurable
				//antes de generar los huevos nuevos, me fijo si supero el limite
				//en caso de superarlo, entonces debo marcar huevos viejos como descartados para poder
				//agregar los nuevos huevos
				
				diffDays = (int)((currentDate.getTime() - chicken.getLastEggDate().getTime()) / 86400000);
				
				ChickenState chickenAvailable = ChickenState.Available;
				if (chicken.getState().equals(chickenAvailable.getState())) {
					if (diffDays >= daysAmountEggs) {
						for (int i=0; i < eggsAmountByChicken;i++) {
							if ((eggCountAvailable +1) > farm.getEggLimit()) {
								Egg egg = apiCall.getOldEgg(farm.getFarmId());
								EggState eggDiscarted = EggState.Discarded;
								egg.setState(eggDiscarted.getState());
								apiCall.updateEgg(egg);
								logger.info("El huevo con id=[" + egg.getEggId() + "] se ha actualizado con estado '" + eggDiscarted.getState() + "'");
								eggsDiscarted++;
							}
							Egg newEgg = new Egg();
							newEgg.setFarmId(farm.getFarmId());
							EggState eggAvailable = EggState.Available;
							newEgg.setState(eggAvailable.getState());
							newEgg.setCreationDate(new Date());
							newEgg.setOrigin("D");
							newEgg = apiCall.insertEgg(newEgg);
							logger.info("Se agrega huevo con id=[" + newEgg.getEggId() + "] con estado '" + eggAvailable.getState() + "'");
							eggCountAvailable++;
							newEggsByChicken++;
						}
						chicken.setLastEggDate(currentDate);
						apiCall.updateChicken(chicken);
						logger.info("Se actualizó la fecha de última puesta [lastEggDate='" + (new SimpleDateFormat("YYYY-MM-dd hh:mm:ss").format(currentDate)) + "'" + "'] del pollo con id=[" + chicken.getChickenId() + "]");
					}
				}
				
			}; //fin for chickens
			
			logger.info("Cantidad de pollos que se actualizaron como muertos: " + chickensDead);
			logger.info("Cantidad de huevos que se actualizaron como descartados: " + eggsDiscarted);
			logger.info("Cantidad de nuevos huevos puestos por gallinas: " + newEggsByChicken);
			
			for(Egg e : eggs){
				
				int diffDays = (int)((currentDate.getTime() - e.getCreationDate().getTime()) / 86400000);
				
				//convertir huevo a pollo
				if (diffDays >= eggToChickensDays) {
					
					//si supero el limite de pollos de la granja, entonces busco el pollo mas viejo y lo marco como
					//descartado para poder agregar uno mas joven. Caso contrario, agrego el pollo directamente
					if ((chickenCountAvailable +1) > farm.getChickenLimit()) {
						Chicken chicken = apiCall.getOldChicken(farm.getFarmId());
						ChickenState chickenDiscarted = ChickenState.Discarded;
						chicken.setState(chickenDiscarted.getState());
						apiCall.updateChicken(chicken);
						logger.info("El pollo con id=[" + chicken.getChickenId() + "] se ha actualizado con estado '" + chickenDiscarted.getState() + "'");
					}
					Chicken newChicken = new Chicken();
					newChicken.setFarmId(farm.getFarmId());
					ChickenState chickenAvailable = ChickenState.Available;
					newChicken.setState(chickenAvailable.getState());
					newChicken.setCreationDate(new Date());
					newChicken.setOrigin("G");
					newChicken.setLastEggDate(newChicken.getCreationDate());
					newChicken = apiCall.insertChicken(newChicken);
					logger.info("Se agrega pollo con id=[" + newChicken.getChickenId() + "] con estado '" + chickenAvailable.getState() + "'");
					EggState eggConvertToChicken = EggState.ConvertToChicken;
					e.setState(eggConvertToChicken.getState());
					apiCall.updateEgg(e);
					logger.info("El huevo con id=[" + e.getEggId() + "] con estado '" + eggConvertToChicken.getState() + "'");				
				}
			}
		}
	}
}
