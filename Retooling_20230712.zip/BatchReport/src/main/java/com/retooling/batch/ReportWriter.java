package com.retooling.batch;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

import com.retooling.batch.entity.CurrentStatusFarm;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

public class ReportWriter implements ItemWriter<CurrentStatusFarm>{
	
	private static final Logger logger = LoggerFactory.getLogger(ReportWriter.class);
	
	@Override
	public void write(Chunk<? extends CurrentStatusFarm> chunk) throws Exception {
		
		if (chunk.isEmpty()) {
			logger.info("No se ha alcanzado ningún límite.");	
		} else {
			logger.info("Escribiendo el reporte de situación actual...");
			
			String fileSuffix = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			
			File file = new File("reporte/situacion_actual_" + fileSuffix +".txt");
			
			FileWriter fw = new FileWriter(file);
			
			PrintWriter pw = new PrintWriter(fw);
			
			CurrentStatusFarm csf = chunk.getItems().get(0); 
			
			pw.println("Reporte de Situación Actual de la Granja");
			pw.println("----------------------------------------");
			pw.println("Nombre: " + csf.getFarmName());
			pw.println();
			pw.println("Dinero disponible: " + csf.getFarmMoney());
			pw.println();
			pw.println("Límite de huevos: " + csf.getEggLimit());
			pw.println();
			pw.println("Cantidad de huevos disponibles: " + csf.getEggsCount());
			pw.println();
			pw.println("Límite de pollos: " + csf.getChickenLimit());
			pw.println();
			pw.println("Cantidad de pollos disponibles: " + csf.getChickensCount());
			pw.close();
		}
		
	}

}
