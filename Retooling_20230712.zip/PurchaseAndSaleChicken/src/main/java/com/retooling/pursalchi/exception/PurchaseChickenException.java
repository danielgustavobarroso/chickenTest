package com.retooling.pursalchi.exception;

public class PurchaseChickenException extends Exception {

	public PurchaseChickenException(String message) {
		super(message);
	}
	
}
