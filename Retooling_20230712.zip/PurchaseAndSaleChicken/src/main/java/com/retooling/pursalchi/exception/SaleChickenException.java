package com.retooling.pursalchi.exception;

public class SaleChickenException extends Exception {

	public SaleChickenException(String message) {
		super(message);
	}
	
}
