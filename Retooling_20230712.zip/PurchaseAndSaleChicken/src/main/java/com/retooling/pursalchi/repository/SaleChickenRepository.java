package com.retooling.pursalchi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.retooling.pursalchi.entity.SaleChicken;

public interface SaleChickenRepository extends MongoRepository<SaleChicken, String>{

}
