package com.retooling.pursalegg.exception;

public class PurchaseEggException extends Exception {

	public PurchaseEggException(String message) {
		super(message);
	}
	
}
