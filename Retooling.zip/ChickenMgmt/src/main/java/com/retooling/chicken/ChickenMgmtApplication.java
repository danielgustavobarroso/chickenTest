package com.retooling.chicken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@EnableDiscoveryClient
@OpenAPIDefinition(servers = {@Server(url = "http://localhost:8011/chicken-ms")})
public class ChickenMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChickenMgmtApplication.class, args);
		System.out.println("Iniciando servicio ChickenMgmtApplication...");
	}

}
