package com.retooling.chicken.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.retooling.chicken.model.Chicken;
import com.retooling.chicken.repository.ChickenRepository;
import com.retooling.chicken.service.ChickenService;

@Service
public class ChickenServiceImpl implements ChickenService {

	@Autowired
	ChickenRepository chickenRepository;

	@Autowired
	MongoTemplate mongoTemplate;
	
	public List<Chicken> getAllChickens() {
		return chickenRepository.findAll();			
	}

	public Optional<Chicken> getChickenById(Integer id) {
		return chickenRepository.findById(id);			
	}
	
	public Chicken saveChicken(Chicken chicken) {
		return chickenRepository.save(chicken);
	}

	public void updateChicken(Chicken chicken) {
		chickenRepository.save(chicken);
	}
	
	public void deleteChicken(Integer id) {
		chickenRepository.deleteById(id);
	}
	
	public List<Chicken> getChickensByFarmId(Integer idFarm) {
		Query query = new Query();
		query.addCriteria(Criteria.where("farmId").is(idFarm));
		List<Chicken> eggs = mongoTemplate.find(query, Chicken.class);
		return eggs;
	}
	
}
