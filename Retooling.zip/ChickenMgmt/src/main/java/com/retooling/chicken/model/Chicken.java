package com.retooling.chicken.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "chickens")
public class Chicken {
	
	@Id
	private int id;
	private int farmId;

	public Chicken() {
		super();
	}
	
	public Chicken(int id, int farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getFarmId() {
		return farmId;
	}

	public void setFarmId(int farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Chicken [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
