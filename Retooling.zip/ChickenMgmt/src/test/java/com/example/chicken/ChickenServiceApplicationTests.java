package com.example.chicken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChickenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
