package com.example.retooling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoolingApplicationTests {

	@Test
	void contextLoads() {
	}

}
