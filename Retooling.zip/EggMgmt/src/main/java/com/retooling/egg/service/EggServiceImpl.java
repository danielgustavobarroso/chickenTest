package com.retooling.egg.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.retooling.egg.model.Egg;
import com.retooling.egg.repository.EggRepository;

@Service
public class EggServiceImpl implements EggService {

	private static final Logger logger = LoggerFactory.getLogger(EggServiceImpl.class);
	
	@Autowired
	EggRepository eggRepository;
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	public List<Egg> getAllEggs() {
		logger.info("Invocando getAllEggs...");
		return eggRepository.findAll();			
	}

	public Optional<Egg> getEggById(String id) {
		logger.info("Invocando getEggById...");
		return eggRepository.findById(id);			
	}
	
	public Egg saveEgg(Egg egg) {
		logger.info("Invocando saveEgg...");
		return eggRepository.save(egg);
	}

	public void updateEgg(Egg egg) {
		logger.info("Invocando updateEgg...");
		eggRepository.save(egg);
	}
	
	public void deleteEgg(String id) {
		logger.info("Invocando deleteEgg...");
		eggRepository.deleteById(id);
	}

	public List<Egg> getEggsByFarmId(String idFarm) {
		logger.info("Invocando getEggsByFarmId...");
		Query query = new Query();
		query.addCriteria(Criteria.where("farmId").is(idFarm));
		List<Egg> eggs = mongoTemplate.find(query, Egg.class);
		return eggs;
	}
	
}
