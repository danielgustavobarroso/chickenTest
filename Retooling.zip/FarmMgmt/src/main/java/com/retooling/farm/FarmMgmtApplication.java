package com.retooling.farm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;

@SpringBootApplication
@EnableDiscoveryClient
@OpenAPIDefinition(servers = {@Server(url = "http://localhost:8011/farm-ms")})
public class FarmMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmMgmtApplication.class, args);
		System.out.println("Iniciando servicio FarmMgmtApplication...");
	}

}
