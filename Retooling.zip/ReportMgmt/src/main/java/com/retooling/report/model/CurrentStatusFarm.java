package com.retooling.report.model;

public class CurrentStatusFarm {
	
	private String farmName;
	private double farmMoney;

	CurrentStatusFarm(String farmName, double farmMoney) {
		super();
		this.farmName = farmName;
		this.farmMoney = farmMoney;
	}
	
	public String getFarmName() {
		return farmName;
	}
	public void setFarmName(String farmName) {
		this.farmName = farmName;
	}
	
	public double getFarmMoney() {
		return farmMoney;
	}

	public void setFarmMoney(double farmMoney) {
		this.farmMoney = farmMoney;
	}

	@Override
	public String toString() {
		return "CurrentStatusFarmReport {farmName=[" + farmName + "], farmMoney=[" + farmMoney + "]}";
	}
	
}
