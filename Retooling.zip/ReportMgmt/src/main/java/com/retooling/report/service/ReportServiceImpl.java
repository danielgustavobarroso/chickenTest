package com.retooling.report.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.report.model.CurrentStatusFarm;
import com.retooling.report.model.Egg;
import com.retooling.report.model.Farm;
import com.retooling.report.model.Chicken;

@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
	private RestTemplate restTemplate;
	
	private String urlFarm    = "http://localhost:8011/farm-ms/api/v1/farms/";
	private String urlEgg     = "http://localhost:8011/egg-ms/api/v1/eggs/farms/";
	private String urlChicken = "http://localhost:8011/chicken-ms/api/v1/chickens/farms/";
	
	public CurrentStatusFarm getCurrentStatusFarm(int id) {
		try {
			CurrentStatusFarm currentStatusFarm = null;
			
			//busco la granja
			Farm f = this.getFarmById(id);
			if (f == null) {
				return currentStatusFarm;
			}
			
			//busco la cantidad de huevos de la granja
			int eggsCount = this.getEggsByFarmId( id);		
			if (eggsCount == -1) {
				return null;
			}

			//busco la cantidad de pollos de la granja
			int chickensCount = this.getChickensByFarmId( id);
			if (chickensCount == -1) {
				return null;
			}
			
			//creo el objeto con los datos del reporte
			currentStatusFarm = new CurrentStatusFarm();
			currentStatusFarm.setFarmName(f.getName());
			currentStatusFarm.setFarmMoney(f.getMoney());
			currentStatusFarm.setEggsCount(eggsCount);
			currentStatusFarm.setChickensCount(chickensCount);
			return currentStatusFarm;

		} catch (HttpClientErrorException e) { 
		    System.out.println(e.getStatusCode());
		    //System.out.println(e.getResponseBodyAsString());
		    return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private Farm getFarmById(int id) {
		try {
			return restTemplate.exchange(urlFarm+id, HttpMethod.GET, null, new ParameterizedTypeReference<Farm>() {}).getBody();
		} catch (HttpClientErrorException e) {
			System.out.println("getFarmById - " + e.getStatusCode());
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	private int getEggsByFarmId(int id) {
		try {
			return restTemplate.exchange(urlEgg+id, HttpMethod.GET, null, new ParameterizedTypeReference<List<Egg>>() {}).getBody().size();
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
				return 0;
			}
			System.out.println("getEggsByFarmId - " + e.getStatusCode());
			return -1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	private int getChickensByFarmId(int id) {
		try {
			return restTemplate.exchange(urlChicken+id, HttpMethod.GET, null, new ParameterizedTypeReference<List<Chicken>>() {}).getBody().size();
		} catch (HttpClientErrorException e) {
			if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
				return 0;
			}
			System.out.println("getEggsByFarmId - " + e.getStatusCode());
			return -1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}
	
}
