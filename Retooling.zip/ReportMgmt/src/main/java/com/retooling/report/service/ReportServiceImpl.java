package com.retooling.report.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.retooling.report.model.CurrentStatusFarm;
import com.retooling.report.model.Farm;

@Service
public class ReportServiceImpl implements ReportService {

	private RestTemplate restTemplate;
	private String urlFarm = "http://localhost:8011/api/v1/farms/";
	
	@Autowired
	CurrentStatusFarm currentStatusFarmReport;
	
	public CurrentStatusFarm getCurrentStatusFarm(int id) {
		
		ResponseEntity<Farm> responseEntity = restTemplate.getForEntity(urlFarm+id, Farm.class);
		
		Farm f = responseEntity.getBody();
		
		currentStatusFarmReport.setFarmName(f.getName());
		currentStatusFarmReport.setFarmMoney(f.getMoney());
		
		return currentStatusFarmReport;
	}
	
}
