package com.retooling.report.model;

public class Chicken {
	
	private int id;
	private int farmId;

	public Chicken() {
		super();
	}
	
	public Chicken(int id, int farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getFarmId() {
		return farmId;
	}

	public void setFarmId(int farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Chicken [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
