package com.retooling.report.model;

public class Egg {
	
	private int id;
	private int farmId;

	public Egg() {
		super();
	}
	
	public Egg(int id, int farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getFarmId() {
		return farmId;
	}

	public void setFarmId(int farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Egg [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
