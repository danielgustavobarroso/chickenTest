package com.retooling.report.service;

import com.retooling.report.model.CurrentStatusFarm;

public interface ReportService {

	public CurrentStatusFarm getCurrentStatusFarm(int id);
	
}
