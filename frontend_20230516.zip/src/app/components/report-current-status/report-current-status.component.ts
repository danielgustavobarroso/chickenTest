import { Component } from '@angular/core';
import { ReportCurrentStatusService } from '../../services/report-current-status.service'

@Component({
  selector: 'app-report-current-status',
  templateUrl: './report-current-status.component.html',
  styleUrls: ['./report-current-status.component.css']
})
export class ReportCurrentStatusComponent {

  constructor(private currentStatusService: ReportCurrentStatusService) { }

  report:any;
  isFetching:boolean = false;
  errorMessage:string = '';

  ngOnInit() {
    this.isFetching = true;
    this.currentStatusService.getCurrentStatusFarm().subscribe(
      response => {
        this.isFetching = false;
        this.report = response;
        console.log("Servicio ReportCurrentStatusFarm - Ok");
      },
      err => {
        this.isFetching = false;
        this.errorMessage = err.message;
        console.error("Servicio ReportCurrentStatusFarm - Error");
      })
  }

}
