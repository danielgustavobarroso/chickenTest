export interface PurchaseChickens {
    id?: string,
    farmId: string,
    purchaseDate: Date,
    units: number,
    price: number,
    totalAmount: number
}