import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FarmComponent } from './components/farm/farm.component';
import { EggComponent } from './components/egg/egg.component';
import { ChickenComponent } from './components/chicken/chicken.component';
import { HttpClientModule } from '@angular/common/http';
import { ReportComponent } from './components/report/report.component';
import { ReportCurrentStatusComponent } from './components/report-current-status/report-current-status.component';
import { CreateFarmComponent } from './components/farm/create-farm/create-farm.component';
import { PurchaseEggsComponent } from './components/purchase-eggs/purchase-eggs.component';
import { AddComponent } from './components/egg/add/add.component';
import { SaleChickensComponent } from './components/sale-chickens/sale-chickens.component';
import { SaleChickensAddComponent } from './components/sale-chickens-add/sale-chickens-add.component';
import { PurchaseChickensComponent } from './components/purchase-chickens/purchase-chickens.component';
import { PurchaseChickensAddComponent } from './components/purchase-chickens-add/purchase-chickens-add.component';

@NgModule({
  declarations: [
    AppComponent,
    FarmComponent,
    EggComponent,
    ChickenComponent,
    ReportComponent,
    ReportCurrentStatusComponent,
    CreateFarmComponent,
    PurchaseEggsComponent,
    AddComponent,
    SaleChickensComponent,
    SaleChickensAddComponent,
    PurchaseChickensComponent,
    PurchaseChickensAddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
