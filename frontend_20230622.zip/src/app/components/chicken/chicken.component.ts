import { Component } from '@angular/core';
import { ChickenService } from '../../services/chicken.service';
import { Chicken } from '../../models/chicken';
import { Router } from '@angular/router';

@Component({
  selector: 'app-chicken',
  templateUrl: './chicken.component.html',
  styleUrls: ['./chicken.component.css']
})
export class ChickenComponent {
  chickens:Chicken[];
  //chickens:any;
  errorMessage:string;
  loading:boolean;

  constructor(private chickenService: ChickenService, private router:Router) {
    this.chickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.getChickens();
  }

  getChickens() {
    this.chickenService.getChickens().subscribe({
      next: (resp:any) => {
        console.log("OK DANI");
        //console.log(data.pollos.length);
        //if (data) {
          this.chickens = resp;
        //}
        //console.log(this.chickens);
        //console.log(Object.keys(this.chickens).length);
        //console.log(this.chickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        console.log("NO OK DANI");
        /*console.log(err);
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }*/

        //console.log(err);
        if (err.error.status != 0) {
          this.errorMessage = err.message;
        }
        this.loading = false;
      }
    });
      //this.loading = false;
  }

  reloadComponent() {
    this.getChickens();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  /*Add() {
    this.router.navigate(['addEgg']);
  }

  Delete(chicken:Chicken) {
    this.chickenService.deleteChicken(chicken.id).subscribe({
      next: (data) => {
        this.chickens = this.chickens.filter(e => e!==chicken);
        alert("Huevo eliminado!");
      },
      error: (err) => {
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          alert('Error en la petición');
        }
      }
    });
  }*/

}
