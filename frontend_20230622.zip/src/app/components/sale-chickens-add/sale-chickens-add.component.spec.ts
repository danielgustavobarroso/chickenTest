import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleChickensAddComponent } from './sale-chickens-add.component';

describe('SaleChickensAddComponent', () => {
  let component: SaleChickensAddComponent;
  let fixture: ComponentFixture<SaleChickensAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleChickensAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaleChickensAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
