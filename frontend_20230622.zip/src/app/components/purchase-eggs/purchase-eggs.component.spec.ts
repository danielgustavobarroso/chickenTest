import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseEggsComponent } from './purchase-eggs.component';

describe('PurchaseEggsComponent', () => {
  let component: PurchaseEggsComponent;
  let fixture: ComponentFixture<PurchaseEggsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseEggsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseEggsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
