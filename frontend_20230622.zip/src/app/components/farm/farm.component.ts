import { Component, OnInit } from '@angular/core';
import { FarmService } from '../../services/farm.service'
import { Farm } from '../../models/farm'

@Component({
  selector: 'app-farm',
  templateUrl: './farm.component.html',
  styleUrls: ['./farm.component.css']
})

export class FarmComponent {
  farms:Farm[];
  errorMessage:string;
  loading:boolean;

  constructor(private farmService: FarmService) {
    this.farms = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.farmService.getFarms().subscribe(
      response => {
        console.log(response);
        this.farms = response;
        if (!this.farms){
          alert('Error en el servidor');
        } else {
          this.loading = false;
        }
      },
      err => {
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.log(err.message);
          alert('Error en la petición');
        }
      })
  }

}
