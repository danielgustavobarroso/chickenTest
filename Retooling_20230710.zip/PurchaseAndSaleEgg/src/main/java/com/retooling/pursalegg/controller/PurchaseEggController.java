package com.retooling.pursalegg.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalegg.entity.Farm;
import com.retooling.pursalegg.entity.PurchaseEgg;
import com.retooling.pursalegg.entity.SaleEgg;
import com.retooling.pursalegg.exception.PurchaseEggException;
import com.retooling.pursalegg.exception.PurchaseEggLimitException;
import com.retooling.pursalegg.exception.PurchaseEggMoneyException;
import com.retooling.pursalegg.service.PurchaseEggService;
import com.retooling.pursalegg.service.SaleEggService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class PurchaseEggController {

	private static final Logger logger = LoggerFactory.getLogger(PurchaseEggController.class);

	@Autowired
	PurchaseEggService service;

	//Obtener todas las compras de huevos
	@GetMapping("purchase-egg")
	public ResponseEntity<List<PurchaseEgg>> getAllPurchaseEggs() {
		logger.info("Controller - Calling method getAllPurchaseEggs...");
		return new ResponseEntity<>(service.getAllPurchaseEggs(), HttpStatus.OK);
	}

	//Guardar una compra de huevos
	@PostMapping("purchase-egg")
	public ResponseEntity<PurchaseEgg> generatePurchaseEgg(@RequestBody PurchaseEgg purchaseEgg) throws PurchaseEggException,
			PurchaseEggMoneyException, PurchaseEggLimitException {		
		logger.info("Controller - Calling method generatePurchaseEgg...");
		return new ResponseEntity<>(service.generatePurchaseEgg(purchaseEgg), HttpStatus.OK);
	}
		
}