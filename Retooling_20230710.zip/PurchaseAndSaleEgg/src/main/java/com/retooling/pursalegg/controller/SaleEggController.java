package com.retooling.pursalegg.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retooling.pursalegg.entity.SaleEgg;
import com.retooling.pursalegg.exception.SaleEggAmountException;
import com.retooling.pursalegg.exception.SaleEggException;
import com.retooling.pursalegg.service.SaleEggService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class SaleEggController {

	private static final Logger logger = LoggerFactory.getLogger(SaleEggController.class);
	
	@Autowired
	SaleEggService service;

	//Obtener todas las ventas de huevos
	@GetMapping("sale-egg")
	public ResponseEntity<List<SaleEgg>> getAllSaleEggs() {
		logger.info("Controller - Calling method getAllSaleEggs...");
		return new ResponseEntity<>(service.getAllSaleEggs(), HttpStatus.OK);
	}

	//Guardar una venta de huevos
	@PostMapping("sale-egg")
	public ResponseEntity<SaleEgg> generateSaleEgg(@RequestBody SaleEgg saleEgg) throws SaleEggException, SaleEggAmountException {		
		logger.info("Controller - Calling method generateSaleEgg...");
		return new ResponseEntity<>(service.generateSaleEgg(saleEgg), HttpStatus.OK);
	}

}