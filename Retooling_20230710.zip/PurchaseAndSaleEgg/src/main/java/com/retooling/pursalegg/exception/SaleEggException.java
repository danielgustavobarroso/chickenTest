package com.retooling.pursalegg.exception;

public class SaleEggException extends Exception {

	public SaleEggException(String message) {
		super(message);
	}
	
}
