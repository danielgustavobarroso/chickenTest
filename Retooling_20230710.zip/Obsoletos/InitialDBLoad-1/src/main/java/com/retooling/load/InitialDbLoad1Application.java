package com.retooling.load;

import java.util.ArrayList;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.retooling.load.entity.Chicken;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
public class InitialDbLoad1Application implements ApplicationRunner{

	private static final Logger logger = LoggerFactory.getLogger(InitialDbLoad1Application.class);
	
	public static void main(String[] args) {
		SpringApplication.run(InitialDbLoad1Application.class, args);
	}

	@Override
	public void run(ApplicationArguments args) {

		String json = "{\"chickenId\":\"1\",\"farmId\":\"2\"}"; 
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			Chicken c = mapper.readValue(json, Chicken.class);
			logger.info(c.toString());
		} catch(JsonMappingException e) {
			e.printStackTrace();
		} catch(JsonProcessingException e) {
			e.printStackTrace();
		}
		
		//JSONArray array = new JSONArray(str);

	}

	
	
}
