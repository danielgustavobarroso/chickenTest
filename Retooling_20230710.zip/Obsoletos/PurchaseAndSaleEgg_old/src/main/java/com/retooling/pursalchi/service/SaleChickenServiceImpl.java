package com.retooling.pursalchi.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.retooling.pursalchi.model.SaleChicken;
import com.retooling.pursalchi.repository.SaleChickenRepository;

@Service
public class SaleChickenServiceImpl implements SaleChickenService {

	private static final Logger logger = LoggerFactory.getLogger(SaleChickenServiceImpl.class);
	
	@Autowired
	SaleChickenRepository saleChickenRepository;

	@Autowired
	MongoTemplate mongoTemplate;
	
	public List<SaleChicken> getAllSaleChickens() {
		logger.info("Invocando getSaleAllChickens...");
		return saleChickenRepository.findAll();			
	}

	public Optional<SaleChicken> getSaleChickenById(String id) {
		logger.info("Invocando getSaleChickenById...");
		return saleChickenRepository.findById(id);			
	}
	
	public SaleChicken saveSaleChicken(SaleChicken saleChicken) {
		logger.info("Invocando saveSaleChicken...");
		return saleChickenRepository.save(saleChicken);
	}

	public void updateSaleChicken(SaleChicken saleChicken) {
		logger.info("Invocando updateSaleChicken...");
		saleChickenRepository.save(saleChicken);
	}
	
	public void deleteSaleChicken(String id) {
		logger.info("Invocando deleteSaleChicken...");
		saleChickenRepository.deleteById(id);
	}
	
}
