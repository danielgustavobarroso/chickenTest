package com.retooling.load.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import java.nio.file.Path;

public class ImportUtils {

	public static List<String> lines(String json){
		String[] split = json.split(json);
		return Arrays.asList(split);
	}
	
	public static List<String> lines(File file) throws IOException{
		return Files.readAllLines(file.toPath());
	}
	
	public static List<String> linesFromResource(String resource) throws IOException {
	    Resource input = new ClassPathResource(resource);
	    Path path = input.getFile().toPath();
	    return Files.readAllLines(path);
	}
	
}
