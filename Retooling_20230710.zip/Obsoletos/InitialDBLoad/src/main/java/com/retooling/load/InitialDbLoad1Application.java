package com.retooling.load;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.retooling.load.service.ImportJsonService;
import com.retooling.load.util.ImportUtils;

@SpringBootApplication
public class InitialDbLoad1Application implements ApplicationRunner {

	private static final Logger logger = LoggerFactory.getLogger(InitialDbLoad1Application.class);
	
	@Autowired
	private ImportJsonService importService;
	
	public static void main(String[] args) {
		SpringApplication.run(InitialDbLoad1Application.class, args);
	}

	@Override
	public void run(ApplicationArguments args) {
		if (args.containsOption("file")) {
			List<String> sources = args.getOptionValues("file");
			for (String source : sources) {
				List<String> jsonLines = new ArrayList<>();
				jsonLines = ImportUtils.linesFromResource(source);
				String result = importService.importTo("chickens", jsonLines);
				logger.info(source + " - result: " + result);
			}
		}


	}

	
}
