package com.retooling.load.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.retooling.load.entity.Farm;

public interface FarmRepository extends MongoRepository<Farm, String>{

	//Necesita el atributo farmId en el modelo para funcionar
	Farm findByFarmId(String id);
	
}
