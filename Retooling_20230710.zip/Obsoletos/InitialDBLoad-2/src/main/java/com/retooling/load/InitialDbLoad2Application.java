package com.retooling.load;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitialDbLoad2Application implements ApplicationRunner{

	private static final Logger logger = LoggerFactory.getLogger(InitialDbLoad2Application.class);
	
	public static void main(String[] args) {
		SpringApplication.run(InitialDbLoad2Application.class, args);
	}

	@Override
	public void run(ApplicationArguments args) {
		logger.info("Starting load data into DB...");


		
		logger.info("Finished");
	}

	
}
