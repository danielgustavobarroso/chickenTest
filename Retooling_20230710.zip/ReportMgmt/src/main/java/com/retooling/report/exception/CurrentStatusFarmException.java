package com.retooling.report.exception;

public class CurrentStatusFarmException extends RuntimeException {

	public CurrentStatusFarmException() {
		super();
	}
	
	public CurrentStatusFarmException(String message) {
		super(message);
	}
	
}
