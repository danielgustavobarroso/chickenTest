package com.retooling.report.service;

import com.retooling.report.entity.CurrentStatusFarm;
import com.retooling.report.exception.CurrentStatusFarmException;

public interface ReportService {

	public CurrentStatusFarm getCurrentStatusFarm(String id) throws CurrentStatusFarmException;
	
}
