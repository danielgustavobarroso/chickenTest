package com.retooling.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.entity.FarmProducts;

@Configuration
public class BatchConfig {

	private static final Logger logger = LoggerFactory.getLogger(BatchConfig.class);
	
	@Autowired
	private RestTemplate restTemplate;	

	@Value("${api.microservice.egg}")
	private String urlEgg;

	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	@Bean
	public Job importUserJob(JobRepository jobRepository, JobCompletionNotificationListener listener, Step step1) {
	    return new JobBuilder("importUserJob", jobRepository)
	      .incrementer(new RunIdIncrementer())
	      .listener(listener)
	      .flow(step1)
	      .end()
	      .build();
	}

	@Bean
	public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		return new StepBuilder("step1", jobRepository)
		  .<FarmProducts, FarmProducts> chunk(1, transactionManager)
	      .reader(reader())
	      //.processor(processor())
	      .writer(writer())
	      .build();
	}

	@Bean
	public ChangeReader reader() {
		return new ChangeReader(restTemplate, urlEgg, urlChicken); 
	}
	
	/*@Bean
	public ReportProcessor processor() {
		return new ReportProcessor();
	}*/

	@Bean
	public ChangeWriter writer() {
		return new ChangeWriter();
	}
	
}
