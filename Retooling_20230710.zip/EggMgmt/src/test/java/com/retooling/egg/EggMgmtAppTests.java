package com.retooling.egg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EggMgmtAppTests {

	@Test
	void contextLoads() {
	}

}
