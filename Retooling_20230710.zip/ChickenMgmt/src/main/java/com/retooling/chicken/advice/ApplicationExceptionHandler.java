package com.retooling.chicken.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.retooling.chicken.exception.ChickenNotFoundException;

/*@RestControllerAdvice
public class ApplicationExceptionHandler {

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(ChickenNotFoundException.class)
	public Map<String, String> handleBusinessException(ChickenNotFoundException ex){
		Map<String, String> errorMap = new HashMap<>();
		errorMap.put("errorMessage", ex.getMessage());
		return errorMap;
	}

	//@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(ChickenNotFoundException.class)
	public ResponseEntity<?> handleBusinessException(ChickenNotFoundException ex){
		Map<String, String> errorMap = new HashMap<>();
		errorMap.put("message", ex.getMessage());
		return new ResponseEntity<>(errorMap, HttpStatus.NOT_FOUND);
	}

	
}*/
