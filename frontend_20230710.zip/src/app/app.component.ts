import { Component } from '@angular/core';
import { FarmService } from './services/farm/farm.service'
import { Farm } from './entities/farm'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Sistema de Gestión de Granjas';
  farms:Farm[];
  farmName:String;

  constructor(private farmService: FarmService) {
    this.farms = [];
    this.farmName = '';
  }

  ngOnInit() {
    this.getFarms();
  }

  getFarms() {
    this.farmService.getFarms().subscribe({
      next: (resp) => {
        this.farms = resp;
        this.farmName = this.farms[0].name;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

}
