export interface Egg {
    eggId: string,
    farmId: string,
    state: string,
    creationDate: Date,
    origin: string
}
