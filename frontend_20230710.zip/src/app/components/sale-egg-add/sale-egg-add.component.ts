import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SaleEggService } from '../../services/sale-egg/sale-egg.service';
import { SaleEgg } from '../../entities/sale-egg';
import { Egg } from '../../entities/egg';
import { EggService } from 'src/app/services/egg/egg.service';

@Component({
  selector: 'app-sale-egg-add',
  templateUrl: './sale-egg-add.component.html',
  styleUrls: ['./sale-egg-add.component.css']
})

export class SaleEggAddComponent {

  saleEgg:SaleEgg;
  errorMessage:string;
  eggs:Egg[];
  unitsAvailable: number;

  constructor(private router:Router, private service:SaleEggService, private eggService:EggService) {
    this.saleEgg = {
      //id: '0',
      farmId: '1',
      saleDate: new Date(),
      units: 0,
      price: 0,
      totalAmount: 0
    };
    this.errorMessage = '';
    this.eggs = [];
    this.unitsAvailable = 0;
    this.getEggs();
  }

  getEggs() {
    this.eggService.getEggs().subscribe({
      next: (resp) => {
        //this.chickens = resp;
        this.eggs = resp.filter(e => e.state == 'D');
        this.unitsAvailable = this.eggs.length;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  modifyTotalAmount(){
    this.saleEgg.totalAmount = this.saleEgg.units * this.saleEgg.price;
  }

  saveSale(){
    if (this.saleEgg.units > this.unitsAvailable) {
      alert('La cantidad de huevos ingresada no puede superar a la disponible.');
    } else {
    //console.log(this.saleChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

      this.service.createSaleEgg(this.saleEgg).subscribe({
        next: (resp:any) => {
          /*console.log(resp);
          if (resp) {
            alert(resp.message);
          } else {
            alert("Venta realizada!");
            this.router.navigate(['saleChicken']);
          }*/
          //this.eggs = this.eggs.filter(e => e!==egg);
          if (resp.status == 207) {
            alert(resp.message);
          } else {
            alert("Venta realizada!");
            this.router.navigate(['saleEgg']);
          }
        },
        error: (err) => {
          /*this.errorMessage = err.message;
          if (this.errorMessage != null) {
            console.error(err.message);
            alert('Error en la petición');
          }*/
          /*this.errorMessage = err.message;
          if (err.error.errorMessage) {
            this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
          }*/
          alert('Error en la petición:\n\n' + err.message);
          //this.loading = false;
        }
      });
      //console.log('Listo');
    }
  }

    goToSaleEggs() {
      this.router.navigate(['saleEgg']);
    }

}
