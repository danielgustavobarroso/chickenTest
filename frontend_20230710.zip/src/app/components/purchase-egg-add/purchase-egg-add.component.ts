import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseEggService } from '../../services/purchase-egg/purchase-egg.service';
import { PurchaseEgg } from '../../entities/purchase-egg';
import { Farm } from '../../entities/farm';
import { FarmService } from 'src/app/services/farm/farm.service';

@Component({
  selector: 'app-purchase-egg-add',
  templateUrl: './purchase-egg-add.component.html',
  styleUrls: ['./purchase-egg-add.component.css']
})
export class PurchaseEggAddComponent {

  purchaseEgg:PurchaseEgg;
  errorMessage:string;
  farms:Farm[];
  moneyAvailable: number;

  constructor(private router:Router, private service:PurchaseEggService, private farmService:FarmService) {
    this.purchaseEgg = {
      //id: '0',
      farmId: '1',
      purchaseDate: new Date,
      units: 0,
      price: 0,
      totalAmount: 0
    };
    this.errorMessage = '';
    this.farms = [];
    this.moneyAvailable = 0;
    this.getFarms();
  }

  getFarms() {
    this.farmService.getFarms().subscribe({
      next: (resp) => {
        this.farms = resp;
        this.moneyAvailable = this.farms[0].money;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  modifyTotalAmount(){
    this.purchaseEgg.totalAmount = this.purchaseEgg.units * this.purchaseEgg.price;
  }

  savePurchase(){
    //console.log(this.purchaseChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

    if (this.purchaseEgg.totalAmount > this.moneyAvailable) {
      console.log("hola");
      alert('La cantidad de dinero de la venta supera al monto disponible.');
    } else {
      console.log("chau");
      this.service.createPurchaseEgg(this.purchaseEgg).subscribe({
        next: (resp:any) => {
          //console.log(resp);
          if (resp.status == 207) {
            alert(resp.message);
          } else {
            alert("Compra realizada!");
            this.router.navigate(['purchaseEgg']);
          }
          //this.eggs = this.eggs.filter(e => e!==egg);
          //alert("Compra realizada!");
          //this.router.navigate(['purchaseChicken']);
        },
        error: (err) => {
          //this.errorMessage = err.message;
          //if (this.errorMessage != null) {
          //  console.error(err.message);
            alert('Error en la petición:\n\n' + err.message);
          //}
        }
      });
      //console.log('Listo');
    }
  }

    goToPurchaseEggs() {
      this.router.navigate(['purchaseEgg']);
    }

}
