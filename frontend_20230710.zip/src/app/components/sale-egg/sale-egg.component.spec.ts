import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleEggComponent } from './sale-egg.component';

describe('SaleEggComponent', () => {
  let component: SaleEggComponent;
  let fixture: ComponentFixture<SaleEggComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleEggComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaleEggComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
