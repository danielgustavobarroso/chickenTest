import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseEggComponent } from './purchase-egg.component';

describe('PurchaseEggComponent', () => {
  let component: PurchaseEggComponent;
  let fixture: ComponentFixture<PurchaseEggComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseEggComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseEggComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
