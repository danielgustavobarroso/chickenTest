import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SaleChickenService } from '../../services/sale-chicken/sale-chicken.service';
import { SaleChicken } from '../../entities/sale-chicken';
import { Chicken } from '../../entities/chicken';
import { ChickenService } from 'src/app/services/chicken/chicken.service';

@Component({
  selector: 'app-sale-chicken-add',
  templateUrl: './sale-chicken-add.component.html',
  styleUrls: ['./sale-chicken-add.component.css']
})

export class SaleChickenAddComponent {

  saleChicken:SaleChicken;
  errorMessage:string;
  chickens:Chicken[];
  unitsAvailable: number;

  constructor(private router:Router, private service:SaleChickenService, private chickenService:ChickenService) {
    this.saleChicken = {
      //id: '0',
      farmId: '1',
      saleDate: new Date(),
      units: 0,
      price: 0,
      totalAmount: 0
    };
    this.errorMessage = '';
    this.chickens = [];
    this.unitsAvailable = 0;
    this.getChickens();
  }

  getChickens() {
    this.chickenService.getChickens().subscribe({
      next: (resp) => {
        //this.chickens = resp;
        this.chickens = resp.filter(c => c.state == 'D');
        this.unitsAvailable = this.chickens.length;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  modifyTotalAmount(){
    this.saleChicken.totalAmount = this.saleChicken.units * this.saleChicken.price;
  }

  saveSale(){
    if (this.saleChicken.units > this.unitsAvailable) {
      alert('La cantidad de pollos ingresada no puede superar a la disponible.');
    } else {
    //console.log(this.saleChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

      this.service.createSaleChickens(this.saleChicken).subscribe({
        next: (resp:any) => {
          /*console.log(resp);
          if (resp) {
            alert(resp.message);
          } else {
            alert("Venta realizada!");
            this.router.navigate(['saleChicken']);
          }*/
          //this.eggs = this.eggs.filter(e => e!==egg);
          if (resp.status == 207) {
            alert(resp.message);
          } else {
            alert("Venta realizada!");
            this.router.navigate(['saleChicken']);
          }
        },
        error: (err) => {
          /*this.errorMessage = err.message;
          if (this.errorMessage != null) {
            console.error(err.message);
            alert('Error en la petición');
          }*/
          /*this.errorMessage = err.message;
          if (err.error.errorMessage) {
            this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
          }*/
          alert('Error en la petición:\n\n' + err.message);
          //this.loading = false;
        }
      });
      //console.log('Listo');
    }
  }

    goToSaleChickens() {
      this.router.navigate(['saleChicken']);
    }

}
