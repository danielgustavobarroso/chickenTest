import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleChickenComponent } from './sale-chicken.component';

describe('SaleChickenComponent', () => {
  let component: SaleChickenComponent;
  let fixture: ComponentFixture<SaleChickenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleChickenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaleChickenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
