package com.retooling.purchase.model;

public class Purchase {

	
	
}
