package com.retooling.report.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retooling.report.model.CurrentStatusFarm;
import com.retooling.report.service.ReportService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
@CrossOrigin(origins = "*")
public class ReportController {

	private static final Logger logger = LoggerFactory.getLogger(ReportController.class);
	
	@Autowired
	ReportService reportService;
	
	//Obtener una granja por id
	@GetMapping("reports/currentStatusFarm/{id}")
	public ResponseEntity<CurrentStatusFarm> createCurrentStatusFarmReport(@PathVariable("id") String id) {
		try {
			logger.info("Iniciando servicio createCurrentStatusFarmReport...");
			CurrentStatusFarm currentStatusFarm = reportService.getCurrentStatusFarm(id);
			if (currentStatusFarm == null) {
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<>(currentStatusFarm, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
