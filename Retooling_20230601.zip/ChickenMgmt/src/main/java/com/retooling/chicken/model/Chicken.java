package com.retooling.chicken.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "chickens")
public class Chicken {
	
	@Id
	private String id;
	private String farmId;

	public Chicken() {
		super();
	}
	
	public Chicken(String id, String farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Chicken [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
