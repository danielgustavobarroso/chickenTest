import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReportCurrentStatusService {

  private url = 'http://localhost:8011/report-ms/api/v1/reports/currentStatusFarm/1';

  constructor(private httpClient: HttpClient) { }

  getCurrentStatusFarm() {
    return this.httpClient.get(this.url);
  }

}
