import { TestBed } from '@angular/core/testing';

import { ReportCurrentStatusService } from './report-current-status.service';

describe('ReportCurrentStatusService', () => {
  let service: ReportCurrentStatusService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReportCurrentStatusService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
