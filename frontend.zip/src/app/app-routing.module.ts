import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FarmComponent } from './farm/farm.component';
import { ChickenComponent } from './chicken/chicken.component';
import { EggComponent } from './egg/egg.component';
import { ReportComponent } from './report/report.component';
import { ReportCurrentStatusComponent } from './report-current-status/report-current-status.component';

const routes: Routes = [
  {path:'', redirectTo: 'farms', pathMatch: 'full'},
  {path: 'farms', component: FarmComponent},
  {path: 'chickens', component: ChickenComponent},
  {path: 'eggs', component: EggComponent},
  {path: 'reports', component: ReportComponent},
  {path: 'reportCurrentStatus', component: ReportCurrentStatusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
