import { Component } from '@angular/core';
import { EggService } from './service/egg.service'

@Component({
  selector: 'app-egg',
  templateUrl: './egg.component.html',
  styleUrls: ['./egg.component.css']
})
export class EggComponent {
  eggs:any;
  isFetching:boolean = false;
  errorMessage:string = '';

  constructor(private eggService: EggService) { }

  ngOnInit() {
    this.isFetching = true;
    this.eggService.getEggs().subscribe(
      response => {
        this.eggs = response;
        console.log("Servicio Egg - Ok");
        this.isFetching = false;
      },
      err => {
        this.errorMessage = err.message;
        console.error("Servicio Egg - Error");
        this.isFetching = false;
      })
  }
}
