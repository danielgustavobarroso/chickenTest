import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class EggService {

  private url = 'http://localhost:8011/api/v1/eggs';

  constructor(private httpClient: HttpClient) {

  }

  getEggs() {
    return this.httpClient.get(this.url);
  }

}
