export interface Farm {
    id: number,
    name: string
}