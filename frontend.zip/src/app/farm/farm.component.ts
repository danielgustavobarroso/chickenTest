import { Component, OnInit } from '@angular/core';
import { FarmService } from './farm.service'
import { Farm } from './farm'

@Component({
  selector: 'app-farm',
  templateUrl: './farm.component.html',
  styleUrls: ['./farm.component.css']
})

export class FarmComponent {
  //farms:Farm[] = [];
  farms:any;
  isFetching:boolean = false;
  errorMessage:string = '';

  constructor(private farmService: FarmService) { }

  ngOnInit() {
    this.isFetching = true;
    this.farmService.getFarms().subscribe(
      response => {
        this.isFetching = false;
        this.farms = response;
        console.log("Servicio Farm - Ok");
      },
      err => {
        this.isFetching = false;
        this.errorMessage = err.message;
        console.error("Servicio Farm - Error");
      })
  }

}
