import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FarmComponent } from './farm/farm.component';
import { EggComponent } from './egg/egg.component';
import { ChickenComponent } from './chicken/chicken.component';
import { HttpClientModule } from '@angular/common/http';
import { ReportComponent } from './report/report.component';
import { ReportCurrentStatusComponent } from './report-current-status/report-current-status.component';

@NgModule({
  declarations: [
    AppComponent,
    FarmComponent,
    EggComponent,
    ChickenComponent,
    ReportComponent,
    ReportCurrentStatusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
