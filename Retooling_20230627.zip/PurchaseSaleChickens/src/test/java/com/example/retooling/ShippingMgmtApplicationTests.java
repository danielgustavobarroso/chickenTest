package com.example.retooling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShippingMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
