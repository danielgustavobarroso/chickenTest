package com.retooling.pursalchi.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.retooling.pursalchi.entity.Chicken;
import com.retooling.pursalchi.entity.Farm;
import com.retooling.pursalchi.entity.PurchaseChicken;
import com.retooling.pursalchi.exception.PurchaseChickenException;
import com.retooling.pursalchi.repository.PurchaseChickenRepository;

@Service
public class PurchaseChickenServiceImpl implements PurchaseChickenService {

	private static final Logger logger = LoggerFactory.getLogger(PurchaseChickenServiceImpl.class);
	
	@Autowired
	PurchaseChickenRepository repository;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private ApiCall apiCall;
	
	public List<PurchaseChicken> getAllPurchaseChickens() {
		logger.info("Service - Calling method getAllChickens...");
		return repository.findAll();	
	}

	public PurchaseChicken savePurchaseChicken(PurchaseChicken purchaseChicken) {
		logger.info("Service - Calling method saveSaleChicken...");
		return repository.save(purchaseChicken);
	}
	
	public PurchaseChicken generatePurchaseChicken(PurchaseChicken purchaseChicken) throws PurchaseChickenException {
	//Map<String, Object> map = new LinkedHashMap<String,Object>();
		logger.info("Service - Calling method generatePurchaseChicken...");
		//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
		//if (chickenExist.isEmpty())
		
		//Farm farm = restTemplate.getForObject(urlFarm+"/"+purchaseChicken.getFarmId(), Farm.class);
		
		Farm farm = null;
		try {
			farm = apiCall.getFarm(purchaseChicken.getFarmId());
		} catch (Exception ex) {
			throw new PurchaseChickenException(ex.getMessage());
		}
		/*Farm farm = null;
		try {
			farm = restTemplate.getForObject(urlFarm+"/"+purchaseChicken.getFarmId(), Farm.class);
		}catch (HttpClientErrorException ex) {
			map.clear();
			map.put("status", 0);
			map.put("message", "Error al buscar datos de granja con id = [" + purchaseChicken.getFarmId() + "]");
			logger.info("Error al buscar datos de granja con id = [" + purchaseChicken.getFarmId() + "]");
			return new ResponseEntity<>(map, HttpStatus.NOT_FOUND);
		}*/
				
		if (purchaseChicken.getTotalAmount() > farm.getMoney()) {
			//map.clear();
			//map.put("status", 0);
			//map.put("message", "La cantidad de dinero utilizada supera el monto disponible.");
			logger.info("La cantidad de dinero utilizada supera el monto disponible.");
			throw new PurchaseChickenException("La cantidad de dinero utilizada supera el monto disponible.");
			//return new ResponseEntity<>(map, HttpStatus.EXPECTATION_FAILED);
		}
		
		//List<Chicken> chickens = new ArrayList<Chicken>();
		//this.getChickens(purchaseChicken.getFarmId(), chickens);
		//Chicken[] chickens = new Chicken[](); 
		
		for(int indice=0;indice<purchaseChicken.getUnits();indice++) {
			Chicken chicken = new Chicken();
			chicken.setFarmId(purchaseChicken.getFarmId());
			try {
				chicken = apiCall.insertChicken(chicken);
				logger.info("Compra - Se agrega pollo: [" + chicken.getId() + "]");
			} catch (Exception ex) {
				throw new PurchaseChickenException(ex.getMessage());
			}
		}

		farm.setMoney(farm.getMoney() - purchaseChicken.getTotalAmount());
		try {
			apiCall.updateFarm(farm);
		} catch (Exception ex) {
			throw new PurchaseChickenException(ex.getMessage());
		}
		
		return this.savePurchaseChicken(purchaseChicken);
	}

	/*	public Optional<PurchaseChicken> getPurchaseChickenById(String id) {
	logger.info("Invocando getPurchaseChickenById...");
	return purchaseChickenRepository.findById(id);			
}*/

	/*public void updatePurchaseChicken(PurchaseChicken purchaseChicken) {
	logger.info("Invocando updatePurchaseChicken...");
	purchaseChickenRepository.save(purchaseChicken);
}

public void deletePurchaseChicken(String id) {
	logger.info("Invocando deletePurchaseChicken...");
	purchaseChickenRepository.deleteById(id);
}*/
	
}
