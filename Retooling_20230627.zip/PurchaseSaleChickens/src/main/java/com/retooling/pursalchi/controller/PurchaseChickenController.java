package com.retooling.pursalchi.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalchi.entity.Chicken;
import com.retooling.pursalchi.entity.Farm;
import com.retooling.pursalchi.entity.PurchaseChicken;
import com.retooling.pursalchi.entity.SaleChicken;
import com.retooling.pursalchi.exception.PurchaseChickenException;
import com.retooling.pursalchi.service.PurchaseChickenService;
import com.retooling.pursalchi.service.SaleChickenService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class PurchaseChickenController {

	private static final Logger logger = LoggerFactory.getLogger(PurchaseChickenController.class);

	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	PurchaseChickenService service;

	//Obtener todas las compras de pollos
	@GetMapping("purchasechicken")
	public ResponseEntity<List<PurchaseChicken>> getAllPurchaseChickens() {
		logger.info("Controller - Calling method getAllPurchaseChickens...");
		return new ResponseEntity<>(service.getAllPurchaseChickens(), HttpStatus.OK);
	}

	//Guardar una compra de pollos
	@PostMapping("purchasechicken")
	public ResponseEntity<PurchaseChicken> generatePurchaseChicken(@RequestBody PurchaseChicken purchaseChicken) throws PurchaseChickenException {		
		logger.info("Controller - Calling method generatePurchaseChicken...");
		return new ResponseEntity<>(service.generatePurchaseChicken(purchaseChicken), HttpStatus.OK);
	}
	
	//Guardar una compra de pollos
	/*@PostMapping("purchasechickens")
	public ResponseEntity<PurchaseChicken> createPurchaseChicken(@RequestBody PurchaseChicken purchaseChicken) {
		try {
			logger.info("Invocando createPurchaseChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
			
			Farm farm = new Farm();
			this.getFarm(purchaseChicken.getFarmId(), farm);
						
			if (purchaseChicken.getTotalAmount() > farm.getMoney()) {
				logger.info("La cantidad de dinero utilizada supera el monto disponible.");
				return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
			}

			//List<Chicken> chickens = new ArrayList<Chicken>();
			//this.getChickens(purchaseChicken.getFarmId(), chickens);
			//Chicken[] chickens = new Chicken[](); 
			
			for(int indice=0;indice<purchaseChicken.getUnits();indice++) {
				Chicken chicken = new Chicken();
				chicken.setFarmId("1");
				chicken = this.addChicken(chicken);
				logger.info("Compra - Se agrega pollo: [" + chicken.getId() + "]");
			}
			
			return new ResponseEntity<>(purchaseChickenService.savePurchaseChicken(purchaseChicken), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void getFarm(String id, Farm farm) {
		try {
			Farm f = restTemplate.getForObject(urlFarm+"/"+id, Farm.class);
			farm.setId(f.getId());
			farm.setName(f.getName());
			farm.setMoney(f.getMoney());
			farm.setChickenLimit(f.getChickenLimit());
			farm.setEggLimit(f.getEggLimit());
		//} catch (HttpClientErrorException ex) {
			//currentStatusFarm.setStatusFarm(ex.getStatusCode().toString());
			//logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	private void getChickens(String id, List<Chicken> chickens) {
		try {
			Chicken[] c = restTemplate.getForObject(urlChicken+"/farms/"+id, Chicken[].class);
			chickens.addAll(Arrays.asList(c));
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}

	private Chicken addChicken(Chicken chicken) {
		try {
			return restTemplate.postForObject(urlChicken, chicken, Chicken.class);
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			return null;
			//e.printStackTrace();
		}
	}
	
	private void deleteChicken(String id) {
		try {
			restTemplate.delete(urlChicken+"/"+id, Chicken.class);
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}*/

//************************************************************
		
}