package com.retooling.pursalchi.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalchi.entity.Chicken;
import com.retooling.pursalchi.entity.Farm;

@Service
public class ApiCall {

	private static final Logger logger = LoggerFactory.getLogger(ApiCall.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.egg}")
	private String urlEgg;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;

	public ApiCall() {
		super();
	}
	
	public Farm getFarm(String id) {
		logger.info("Service - Calling getFarm...");
		Farm farm = restTemplate.getForObject(urlFarm+"/{id}", Farm.class, id);
		return farm;
	}

	public void updateFarm(Farm farm) {
		logger.info("Service - Calling updateFarm...");
		restTemplate.put(urlFarm, farm, Farm.class);
	}
	
	/*public List<Egg> getEggs(String idFarm) {
		logger.info("Service - Calling getEggs...");
		Egg[] e = restTemplate.getForObject(urlEgg+"/{idFarm}", Egg[].class, idFarm);
		return Arrays.asList(e);
	}*/

	public List<Chicken> getChickens(String idFarm) {
		logger.info("Service - Calling getChickens...");
		return Arrays.asList(restTemplate.getForObject(urlChicken+"/{idFarm}", Chicken[].class, idFarm));
	}

	public Chicken insertChicken(Chicken chicken) {
		logger.info("Service - Calling insertChicken...");
		return restTemplate.postForObject(urlChicken, chicken, Chicken.class);
	}
	
}
