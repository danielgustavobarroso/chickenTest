package com.retooling.chicken.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "chickens")
public class Chicken {
	
	@Id
	private String chickenId;
	//private String id;
	private String farmId;

	public Chicken() {
		super();
	}
	
	public Chicken(String chickenId, String farmId) {
		super();
		this.chickenId = chickenId;
		this.farmId = farmId;
	}
	
	public String getId() {
		return chickenId;
	}
	public void setId(String chickenId) {
		this.chickenId = chickenId;
	}

	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Chicken [chickenId=" + chickenId + ", farmId=" + farmId + "]";
	}
	
}
