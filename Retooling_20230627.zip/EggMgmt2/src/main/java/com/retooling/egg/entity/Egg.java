package com.retooling.egg.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "eggs")
public class Egg {
	
	@Id
	private String eggId;
	//private String id;
	private String farmId;

	public Egg() {
		super();
	}
	
	public Egg(String eggId, String farmId) {
		super();
		this.eggId = eggId;
		this.farmId = farmId;
	}
	
	public String getId() {
		return eggId;
	}
	public void setId(String eggId) {
		this.eggId = eggId;
	}
	
	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Egg [eggId=" + eggId + ", farmId=" + farmId + "]";
	}
	
}
