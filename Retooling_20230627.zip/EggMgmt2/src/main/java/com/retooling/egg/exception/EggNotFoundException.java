package com.retooling.egg.exception;

public class EggNotFoundException extends Exception {

	public EggNotFoundException(String message) {
		super(message);
	}
	
}
