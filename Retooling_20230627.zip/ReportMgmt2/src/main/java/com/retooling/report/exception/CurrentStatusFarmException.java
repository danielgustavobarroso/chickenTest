package com.retooling.report.exception;

public class CurrentStatusFarmException extends Exception {

	public CurrentStatusFarmException(String message) {
		super(message);
	}
	
}
