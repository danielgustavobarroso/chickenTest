package com.retooling.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.model.CurrentStatusFarm;

@Configuration
public class BatchConfig {

	private static final Logger logger = LoggerFactory.getLogger(BatchConfig.class);
	
	@Autowired
	private RestTemplate restTemplate;	

	@Value("${api.microservice.report}")
	private String url;
	
	@Bean
	public Job importUserJob(JobRepository jobRepository, JobCompletionNotificationListener listener, Step step1) {
	    return new JobBuilder("importUserJob", jobRepository)
	      .incrementer(new RunIdIncrementer())
	      .listener(listener)
	      .flow(step1)
	      .end()
	      .build();
	}

	@Bean
	public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		return new StepBuilder("step1", jobRepository)
		  .<CurrentStatusFarm, CurrentStatusFarm> chunk(1, transactionManager)
	      .reader(reader())
	      .processor(processor())
	      .writer(writer())
	      .build();
	}

	@Bean
	public ReportReader reader() {
		return new ReportReader(restTemplate, url); 
	}
	
	@Bean
	public ReportProcessor processor() {
		return new ReportProcessor();
	}

	@Bean
	public ReportWriter writer() {
		return new ReportWriter();
	}
	
	/*@Bean
	public FlatFileItemWriter<CurrentStatusFarm> writer() {
		logger.info("Escribiendo la información del reporte de situación actual...");
		FlatFileItemWriter<CurrentStatusFarm> writer = new FlatFileItemWriter<CurrentStatusFarm>();
		writer.setResource(new FileSystemResource("reporte/situacion_actual.txt"));
		writer.setAppendAllowed(false);
	    writer.setLineAggregator(new DelimitedLineAggregator<CurrentStatusFarm>() {
	    	{
	    		setDelimiter(",");
	    		setFieldExtractor(new BeanWrapperFieldExtractor<CurrentStatusFarm>() {
	    			{
	    				setNames(new String[] { "farmId", "farmName" });
	    			}
	    		});
	    	}
	    });
	    return writer;
	}*/

	
	/*@Bean
	public MongoItemReader<Farm> reader() {
		MongoItemReader<Farm> reader = new MongoItemReader<>();
		reader.setTemplate(mongoTemplate);
		reader.setSort(new HashMap<String, Sort.Direction>() {{
			put("_id", Direction.DESC);
		}});
		reader.setTargetType(Farm.class);
		reader.setQuery("{}");
		return reader;
	}*/
	
/*	@Bean
	public FlatFileItemWriter<Farm> writer() {
		FlatFileItemWriter<Farm> writer = new FlatFileItemWriter<Farm>();
		writer.setResource(new FileSystemResource("reporte/situacion_actual.txt"));
		writer.setAppendAllowed(false);
	    writer.setLineAggregator(new DelimitedLineAggregator<Farm>() {
	    	{
	    		setDelimiter(",");
	    		setFieldExtractor(new BeanWrapperFieldExtractor<Farm>() {
	    			{
	    				setNames(new String[] { "id", "name" });
	    			}
	    		});
	    	}
	    });
	    return writer;
	}*/
	
	/*@Bean
	public ItemWriter<Farm> writer() {
		//MongoItemReader<Farm> reader = new MongoItemReader<Farm>();
		//reader.setCollection("farms");
		//reader.se
	    return null;
	}
	
	@Bean
	public MongoItemReader<Farm> reader() {
		MongoItemReader<Farm> reader = new MongoItemReader<Farm>();
		reader.setCollection("farms");
		//reader.se
	    return reader;
	}*/
	
/*	@Bean
	public CoffeeItemProcessor processor() {
	    return new CoffeeItemProcessor();
	}*/

	
}
