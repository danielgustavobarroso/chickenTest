package com.retooling.report.model;

public class Egg {
	
	private String id;
	private String farmId;

	public Egg() {
		super();
	}
	
	public Egg(String id, String farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Egg [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
