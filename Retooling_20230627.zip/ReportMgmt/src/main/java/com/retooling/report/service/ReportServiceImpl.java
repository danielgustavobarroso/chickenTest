package com.retooling.report.service;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.report.model.CurrentStatusFarm;
import com.retooling.report.model.Egg;
import com.retooling.report.model.Farm;
import com.retooling.report.model.Chicken;

@Service
public class ReportServiceImpl implements ReportService {

	private static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.egg}")
	private String urlEgg;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	public CurrentStatusFarm getCurrentStatusFarm(String id) {
		try {
			logger.info("Iniciando servicio getCurrentStatusFarm...");
			
			//Creo objeto reporte y seteo id de granja 
			CurrentStatusFarm currentStatusFarm = new CurrentStatusFarm();
			currentStatusFarm.setFarmId(id);
			
			//Busco datos de granja. Si la encuentra, entonces busca cantidad de huevos y pollos
			//Caso contrario, no busca cantidad de huevos y pollos y setea estados como NO OK
			this.getFarm(currentStatusFarm);
			if ("OK".equals(currentStatusFarm.getStatusFarm())) {
				this.getEggs(currentStatusFarm);
				this.getChickens(currentStatusFarm);	
			} else {
				currentStatusFarm.setChickensCount(0);
				currentStatusFarm.setStatusChickens("NO_OK");
				currentStatusFarm.setEggsCount(0);
				currentStatusFarm.setStatusEggs("NO_OK");
			}
			
			return currentStatusFarm;
		//} catch (HttpClientErrorException e) {
		//	System.out.println(e.getStatusCode());
		    //System.out.println(e.getResponseBodyAsString());
		//    return null;
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			//e.printStackTrace();
			return null;
		}
	}
	
	private void getFarm(CurrentStatusFarm currentStatusFarm) {
		try {
			Farm f = restTemplate.getForObject(urlFarm+currentStatusFarm.getFarmId(), Farm.class);			
			currentStatusFarm.setFarmName(f.getName());
			currentStatusFarm.setFarmMoney(f.getMoney());
			currentStatusFarm.setChickenLimit(f.getChickenLimit());
			currentStatusFarm.setEggLimit(f.getEggLimit());
			currentStatusFarm.setStatusFarm("OK");
		//} catch (HttpClientErrorException ex) {
			//currentStatusFarm.setStatusFarm(ex.getStatusCode().toString());
			//logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			currentStatusFarm.setStatusFarm("NO_OK");
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	private void getEggs(CurrentStatusFarm currentStatusFarm) {
		try {
			Egg[] e = restTemplate.getForObject(urlEgg+currentStatusFarm.getFarmId(), Egg[].class);
			currentStatusFarm.setEggsCount(Arrays.asList(e).size());
			currentStatusFarm.setStatusEggs("OK");
		} catch (HttpClientErrorException.NotFound ex) {
			currentStatusFarm.setEggsCount(0);
			currentStatusFarm.setStatusEggs("OK");
			//currentStatusFarm.setStatusEggs(ex.getStatusCode().toString());
			//logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			currentStatusFarm.setStatusEggs("NO_OK");
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	private void getChickens(CurrentStatusFarm currentStatusFarm) {
		try {
			Chicken[] e = restTemplate.getForObject(urlChicken+currentStatusFarm.getFarmId(), Chicken[].class);
			currentStatusFarm.setChickensCount(Arrays.asList(e).size());
			currentStatusFarm.setStatusChickens("OK");
		} catch (HttpClientErrorException.NotFound ex) {
			currentStatusFarm.setChickensCount(0);
			currentStatusFarm.setStatusChickens("OK");			
			//currentStatusFarm.setStatusChickens(ex.getStatusCode().toString());
			//logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			currentStatusFarm.setStatusChickens("NO_OK");
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
}
