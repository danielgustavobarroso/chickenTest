package com.retooling.batch;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.retooling.batch.entity.Chicken;
import com.retooling.batch.entity.Egg;
import com.retooling.batch.entity.Farm;
import com.retooling.batch.entity.FarmAnimals;

public class ReportWriter implements ItemWriter<FarmAnimals>{

	private static final Logger logger = LoggerFactory.getLogger(ReportWriter.class);
	
	@Autowired
	private ApiCall apiCall;
	
	@Value("${batch.config.chicken-dead-days}") //90
	private int chickenDeadDays;	
	
	@Value("${batch.config.egg-to-chicken-days}") //60
	private int eggToChickensDays;
	
	@Value("${batch.config.days-amount-eggs}") //30
	private int daysAmountEggs;	
	
	@Value("${batch.config.eggs-amount-by-chicken}") //10
	private int eggsAmountByChicken;
	
	@Override
	public void write(Chunk<? extends FarmAnimals> chunk) throws Exception {
		
		/*if (chunk.isEmpty()) {
			logger.info("No se ha alcanzado ningún límite.");	
		} else {*/
			logger.info("Escribiendo el reporte de situación actual...");
			
			Farm farm = null;
			//try {
				farm = apiCall.getFarm("1");
			//} catch (Exception ex) {
			//	throw new Exception("Error in ms-farm microservice");
			//}
			
			//obtengo la cantidad de dias y se la sumo a la fecha actual
			String days = System.getProperty("days");
			Date currentDate = new Date();
			Calendar c = Calendar.getInstance();
			c.setTime(currentDate);
			c.add(Calendar.DATE, Integer.valueOf(days));
			currentDate = c.getTime();
			
			//Date currentDate = new SimpleDateFormat("yyyy-MM-dd").parse(System.getProperty("systemDate"));
			
			//logger.info(currentDate.toString());
			//logger.info(currentDate3.toString());
			
			//LocalDate currentDate = LocalDate.now();
				
			FarmAnimals fa = chunk.getItems().get(0); 
			
			List<Egg> eggs = fa.getEggs();
			int eggCountAvailable = eggs.size(); 
					
			List<Chicken> chickens = fa.getChickens();
			int chickenCountAvailable = chickens.size();
			
			logger.info("Cantidad de huevos disponibles: " + eggCountAvailable);
			logger.info("Cantidad de pollos disponibles: " + chickenCountAvailable);
			
			for(Chicken chicken : chickens){
				
				int diffDays = (int)((currentDate.getTime() - chicken.getCreationDate().getTime()) / 86400000);
				
				//marcar pollo como muerto si corresponde
				if (diffDays > chickenDeadDays) {
					chicken.setState("M");
					apiCall.updateChicken(chicken);
					logger.info("El pollo con id=[" + chicken.getChickenId() + "] se ha actualizado con estado 'Muerto'");
				}
				
				//creo nuevos huevos si corresponde
				//obtengo la cantidad de dias entre la fecha actual y la fecha de la ultima vez que puso huevos
				//si esa cantidad supera la cantidad de dias que deben pasar para poner huevos, entonces
				//creo x cantidad de huevos nuevos, donde x es tambien una cantidad configurada
				//antes de generar los huevos nuevos, me fijo si supero el limite
				//en caso de superarlo, entonces debo marcar huevos viejos como regalados para poder
				//agregar los nuevos huevos
				if (diffDays > chickenDeadDays) {
					
				}
				
			};
			//logger.info("Hola\n" + fa.toString())
			
			for(Egg e : eggs){
				//logger.info(e.toString());
				
				//LocalDate chickenDate = LocalDate.parse(e.getCreationDate());
				
				int diffDays = (int)((currentDate.getTime() - e.getCreationDate().getTime()) / 86400000);
				
				//convertir huevo a pollo
				if (diffDays > eggToChickensDays) {
					
					//si supero el limite de la granja, entonces busco el pollo mas viejo y lo marco como regalado
					//para poder agregar uno mas joven. Caso contrario, agrego el pollo directamente
					if ((eggCountAvailable +1) > farm.getEggLimit()) {
						Chicken chicken = apiCall.getOldChicken(farm.getFarmId());						
						chicken.setState("R");
						apiCall.updateChicken(chicken);
						//chickenCountAvailable--;
						logger.info("El pollo con id=[" + chicken.getChickenId() + "] se ha actualizado con estado 'Regalado'");
					}
					Chicken newChicken = new Chicken();
					newChicken.setFarmId(farm.getFarmId());
					newChicken.setState("D");
					newChicken.setCreationDate(new Date());
					newChicken.setOrigin("C");
					//try {
					newChicken = apiCall.insertChicken(newChicken);
					logger.info("Se agrega pollo con id=[" + newChicken.getChickenId() + "]");
					e.setState("G");
					apiCall.updateEgg(e);
					logger.info("Se agrega pollo con id=[" + newChicken.getChickenId() + "]");				
				}
				
			};
			
		//}
		
	}

}
