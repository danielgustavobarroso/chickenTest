package com.retooling.batch;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.entity.Chicken;
import com.retooling.batch.entity.Egg;
import com.retooling.batch.entity.Farm;

@Service
public class ApiCall {

	private static final Logger logger = LoggerFactory.getLogger(ApiCall.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.egg}")
	private String urlEgg;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;

	public ApiCall() {
		super();
	}
	
	public Farm getFarm(String id) {
		logger.info("Service - Calling getFarm...");
		return restTemplate.getForObject(urlFarm+"/{id}", Farm.class, id);
	}
	
	public List<Egg> getEggs(String idFarm) {
		logger.info("Service - Calling getEggs...");
		return Arrays.asList(restTemplate.getForObject(urlEgg+"/{idFarm}", Egg[].class, idFarm))
				.stream().filter(c -> c.getState().equals("D")).collect(Collectors.toList());
	}

	public List<Chicken> getChickens(String idFarm) {
		logger.info("Service - Calling getChickens...");
		return Arrays.asList(restTemplate.getForObject(urlChicken+"/{idFarm}", Chicken[].class, idFarm))
				.stream().filter(c -> c.getState().equals("D")).collect(Collectors.toList());
	}

	public Chicken getOldChicken(String idFarm) {
		logger.info("Service - Calling getOldChicken...");
		return Arrays.asList(restTemplate.getForObject(urlChicken+"/{idFarm}", Chicken[].class, idFarm))
				.stream().filter(c -> c.getState().equals("D")).collect(Collectors.toList()).get(0);
	}
	
	public Egg insertEgg(Egg egg) {
		logger.info("Service - Calling insertEgg...");
		return restTemplate.postForObject(urlEgg, egg, Egg.class);
	}
	
	public void updateChicken(Chicken chicken) {
		logger.info("Service - Calling updateChicken...");
		restTemplate.put(urlChicken, chicken, Chicken.class);
	}

	public Chicken insertChicken(Chicken chicken) {
		logger.info("Service - Calling insertChicken...");
		return restTemplate.postForObject(urlChicken, chicken, Chicken.class);
	}
	
	public void updateEgg(Egg egg) {
		logger.info("Service - Calling updateEgg...");
		restTemplate.put(urlEgg, egg, Egg.class);
	}
	
}
