package com.retooling.batch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.entity.Chicken;
import com.retooling.batch.entity.Egg;
import com.retooling.batch.entity.FarmAnimals;

public class ReportReader implements ItemReader<FarmAnimals> {

	private static final Logger logger = LoggerFactory.getLogger(ReportReader.class);

	private int nextFarmAnimalsIndex;
	private List<FarmAnimals> farmAnimalsData;
	//private List<Chicken> chickenData;
	
	private RestTemplate restTemplate;
	private String urlEgg;
	private String urlChicken;
	
	public ReportReader(RestTemplate restTemplate, String urlEgg, String urlChicken) {
		this.restTemplate = restTemplate;
		this.urlEgg = urlEgg;
		this.urlChicken = urlChicken;
		nextFarmAnimalsIndex = 0;
	}
	
	@Override
	public FarmAnimals read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		
/*		if (farmAnimalsDataIsNotInitialized()) {
			logger.info("Leyendo la información de los animales de la granja...");
			FarmAnimals fa = new FarmAnimals();
			fa.setEggs(fetchEggDatafromAPI());
			fa.setChickens(fetchChickenDatafromAPI());
			farmAnimalsData = new ArrayList<FarmAnimals>();
			farmAnimalsData.add(fa);
		}
		
		FarmAnimals nextFarmAnimals = null;
		if (nextFarmAnimalsIndex < farmAnimalsData.size()) {
			nextFarmAnimals = farmAnimalsData.get(nextFarmAnimalsIndex);
			nextFarmAnimalsIndex++;
		} else {
			nextFarmAnimalsIndex = 0;
			farmAnimalsData = null;
		}
				
		return nextFarmAnimals;*/
		
		if (getIterator().hasNext()) {
			return getIterator().next();
		}
		return null;
	}

	/*private boolean farmAnimalsDataIsNotInitialized() {
		return this.farmAnimalsData == null;
	}*/
	
	private List<Egg> fetchEggDatafromAPI() {
		return Arrays.asList(restTemplate.getForObject(urlEgg, Egg[].class)).stream()
				.filter(e -> e.getState().equals("D")).collect(Collectors.toList());
	}

	private List<Chicken> fetchChickenDatafromAPI() {
		return Arrays.asList(restTemplate.getForObject(urlChicken, Chicken[].class))
				.stream().filter(c -> c.getState().equals("D")).collect(Collectors.toList());
	}
	
	public Iterator<FarmAnimals> getIterator() {
		List<FarmAnimals> list = new ArrayList<FarmAnimals>();
		FarmAnimals fa = new FarmAnimals();
		fa.setEggs(fetchEggDatafromAPI());
		fa.setChickens(fetchChickenDatafromAPI());
		list.add(fa);
		return list.iterator();
	}
	
}
