package com.retooling.batch;

/*import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.retooling.batch.entity.CurrentStatusFarm;

public class ReportProcessor implements ItemProcessor<CurrentStatusFarm, CurrentStatusFarm>{

	private static final Logger logger = LoggerFactory.getLogger(ReportProcessor.class);
	
	@Override
	public CurrentStatusFarm process(CurrentStatusFarm item) throws Exception {
		logger.info("Procesando la información del reporte de situación actual...");
		
		if ((item.getEggsCount() == item.getEggLimit()) || (item.getChickensCount() == item.getChickenLimit())) {
			return item;
		} else {
			return null;	
		}
	}
	
}*/
