package com.retooling.farm.service;

import com.retooling.farm.service.FarmService;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retooling.farm.FarmMgmtApplication;
import com.retooling.farm.model.Farm;
import com.retooling.farm.repository.FarmRepository;

@Service
public class FarmServiceImpl implements FarmService {

	private static final Logger logger = LoggerFactory.getLogger(FarmServiceImpl.class);
	
	@Autowired
	FarmRepository farmRepository;
	
	public List<Farm> getAllFarms() {
		logger.info("Invocando getAllFarms...");
		return farmRepository.findAll();			
	}

	public Optional<Farm> getFarmById(String id) {
		logger.info("Invocando getFarmById...");
		return farmRepository.findById(id);			
	}
	
	public Farm saveFarm(Farm farm) {
		logger.info("Invocando saveFarm...");
		return farmRepository.save(farm);
	}

	public void updateFarm(Farm farm) {
		logger.info("Invocando updateFarm...");
		farmRepository.save(farm);
	}
	
	public void deleteFarm(String id) {
		logger.info("Invocando deleteFarm...");
		farmRepository.deleteById(id);
	}
	
}
