package com.retooling.pursalchi.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalchi.entity.Chicken;
import com.retooling.pursalchi.entity.Farm;
import com.retooling.pursalchi.entity.PurchaseChicken;
import com.retooling.pursalchi.entity.SaleChicken;
import com.retooling.pursalchi.exception.PurchaseChickenException;
import com.retooling.pursalchi.exception.PurchaseChickenMoneyException;
import com.retooling.pursalchi.service.PurchaseChickenService;
import com.retooling.pursalchi.service.SaleChickenService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class PurchaseChickenController {

	private static final Logger logger = LoggerFactory.getLogger(PurchaseChickenController.class);

	@Autowired
	PurchaseChickenService service;

	//Obtener todas las compras de pollos
	@GetMapping("purchase-chicken")
	public ResponseEntity<List<PurchaseChicken>> getAllPurchaseChickens() {
		logger.info("Controller - Calling method getAllPurchaseChickens...");
		return new ResponseEntity<>(service.getAllPurchaseChickens(), HttpStatus.OK);
	}

	//Guardar una compra de pollos
	@PostMapping("purchase-chicken")
	public ResponseEntity<PurchaseChicken> generatePurchaseChicken(@RequestBody PurchaseChicken purchaseChicken) throws PurchaseChickenException, PurchaseChickenMoneyException {		
		logger.info("Controller - Calling method generatePurchaseChicken...");
		return new ResponseEntity<>(service.generatePurchaseChicken(purchaseChicken), HttpStatus.OK);
	}
		
}