package com.retooling.batch;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.entity.CurrentStatusFarm;

public class ReportReader implements ItemReader<CurrentStatusFarm> {

	private static final Logger logger = LoggerFactory.getLogger(ReportReader.class);

	private int nextCurrentStatusFarmIndex;
	private List<CurrentStatusFarm> currentStatusFarmData;
	
	private RestTemplate restTemplate;
	private String url;
	
	public ReportReader(RestTemplate restTemplate, String url) {
		this.restTemplate = restTemplate;
		this.url = url;
		nextCurrentStatusFarmIndex = 0;
	}
	
	@Override
	public CurrentStatusFarm read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		
		if (currentStatusFarmDataIsNotInitialized()) {
			logger.info("Leyendo la información del reporte de situación actual...");
			currentStatusFarmData = fetchCurrentStatusFarmDatafromAPI();
		}
		
		CurrentStatusFarm nextCurrentStatusFarm = null;
		if (nextCurrentStatusFarmIndex < currentStatusFarmData.size()) {
			nextCurrentStatusFarm = currentStatusFarmData.get(nextCurrentStatusFarmIndex);
			nextCurrentStatusFarmIndex++;
		} else {
			nextCurrentStatusFarmIndex = 0;
			currentStatusFarmData = null;
		}
				
		return nextCurrentStatusFarm;
	}

	private boolean currentStatusFarmDataIsNotInitialized() {
		return this.currentStatusFarmData == null;
	}
	
	private List<CurrentStatusFarm> fetchCurrentStatusFarmDatafromAPI() {
		CurrentStatusFarm currentStatusFarm = restTemplate.getForObject(url+"/1", CurrentStatusFarm.class);
		CurrentStatusFarm[] list = {currentStatusFarm};
		return Arrays.asList(list);
	}
	
}
