package com.retooling.report.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import com.retooling.report.entity.Chicken;
import com.retooling.report.entity.CurrentStatusFarm;
import com.retooling.report.entity.Egg;
import com.retooling.report.entity.Farm;
import com.retooling.report.exception.CurrentStatusFarmException;

@Service
public class ReportServiceImpl implements ReportService {

	private static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);
	
	@Autowired
	private ApiCall apiCall;
	
	@Override
	public CurrentStatusFarm getCurrentStatusFarm(String id) throws CurrentStatusFarmException {
		logger.info("Iniciando servicio getCurrentStatusFarm...");
		CurrentStatusFarm currentStatusFarm = new CurrentStatusFarm();
		
		Farm farm = null;
		try {
			farm = apiCall.getFarm(id);
		} catch (Exception ex) {
			throw new CurrentStatusFarmException("Error in ms-farm microservice");
		}

		List<Egg> eggs = null;
		try {
			eggs = apiCall.getEggs(id);
		} catch (HttpClientErrorException.NotFound ex) {
			eggs = new ArrayList<>();
		} catch (Exception ex) {
			throw new CurrentStatusFarmException("Error in ms-egg microservice");
		}
				
		List<Chicken> chickens = null;
		try {
			chickens = apiCall.getChickens(id);
		} catch (HttpClientErrorException.NotFound ex) {
			chickens = new ArrayList<>();
		} catch (Exception ex) {
			throw new CurrentStatusFarmException("Error in ms-chicken microservice");
		}
			
		currentStatusFarm.setFarmId(farm.getFarmId());
		currentStatusFarm.setFarmName(farm.getName());
		currentStatusFarm.setFarmMoney(farm.getMoney());
		currentStatusFarm.setChickenLimit(farm.getChickenLimit());
		currentStatusFarm.setEggLimit(farm.getEggLimit());
		currentStatusFarm.setEggsCount(eggs.size());
		currentStatusFarm.setChickensCount(chickens.size());		
		return currentStatusFarm;
	}
}
