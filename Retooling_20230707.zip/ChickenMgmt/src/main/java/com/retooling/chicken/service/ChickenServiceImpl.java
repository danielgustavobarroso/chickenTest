package com.retooling.chicken.service;

import java.util.List;
//import java.util.Optional;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.retooling.chicken.model.Chicken;
import com.retooling.chicken.repository.ChickenRepository;

@Service
public class ChickenServiceImpl implements ChickenService {

	private static final Logger logger = LoggerFactory.getLogger(ChickenServiceImpl.class);
	
	@Autowired
	ChickenRepository chickenRepo;

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public List<Chicken> getAllChickens() {
		logger.info("Invocando service getAllChickens...");
		return chickenRepo.findAll();			
	}

	@Override
	public Optional<Chicken> getChickenById(String id) {
		logger.info("Invocando service getChickenById...");
		return chickenRepo.findById(id);			
	}
	
	@Override
	public Chicken saveChicken(Chicken chicken) {
		logger.info("Invocando service saveChicken...");
		return chickenRepo.save(chicken);
	}

	@Override
	public void updateChicken(Chicken chicken) {
		logger.info("Invocando updateChicken...");
		chickenRepo.save(chicken);
	}
	
	@Override
	public void deleteChicken(String id) {
		logger.info("Invocando service deleteChicken...");
		chickenRepo.deleteById(id);
	}
	
	@Override
	public List<Chicken> getChickensByFarmId(String idFarm) {
		logger.info("Invocando service getChickensByFarmId...");
		Query query = new Query();
		query.addCriteria(Criteria.where("farmId").is(idFarm));
		List<Chicken> chickens = mongoTemplate.find(query, Chicken.class);
		return chickens;
	}
	
}
