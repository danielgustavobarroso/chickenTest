export interface Chicken {
    chickenId: string,
    farmId: string,
    state: string,
    creationDate: Date,
    origin: string,
    lastEggDate: Date
}