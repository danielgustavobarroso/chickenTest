import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FarmComponent } from './components/farm/farm.component';
import { EggListComponent } from './components/egg-list/egg-list.component';
import { ChickenListComponent } from './components/chicken-list/chicken-list.component';
import { HttpClientModule } from '@angular/common/http';
//import { ReportComponent } from './components/report/report.component';
import { ReportCurrentStatusComponent } from './components/report-current-status/report-current-status.component';
//import { CreateFarmComponent } from './components/farm/create-farm/create-farm.component';
import { SaleChickenComponent } from './components/sale-chicken/sale-chicken.component';
import { SaleChickenAddComponent } from './components/sale-chicken-add/sale-chicken-add.component';
import { PurchaseChickenComponent } from './components/purchase-chicken/purchase-chicken.component';
import { PurchaseChickenAddComponent } from './components/purchase-chicken-add/purchase-chicken-add.component';
import { SaleEggComponent } from './components/sale-egg/sale-egg.component';
import { SaleEggAddComponent } from './components/sale-egg-add/sale-egg-add.component';
import { PurchaseEggComponent } from './components/purchase-egg/purchase-egg.component';
import { PurchaseEggAddComponent } from './components/purchase-egg-add/purchase-egg-add.component';
import { WelcomeComponent } from './components/welcome/welcome.component';

@NgModule({
  declarations: [
    AppComponent,
    FarmComponent,
    EggListComponent,
    ChickenListComponent,
//    ReportComponent,
    ReportCurrentStatusComponent,
//    CreateFarmComponent,
    SaleChickenComponent,
    SaleChickenAddComponent,
    PurchaseChickenComponent,
    PurchaseChickenAddComponent,

    SaleEggComponent,
    SaleEggAddComponent,
    PurchaseEggComponent,
    PurchaseEggAddComponent,

    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
