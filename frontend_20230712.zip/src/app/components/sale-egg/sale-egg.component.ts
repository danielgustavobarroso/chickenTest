import { Component } from '@angular/core';
import { SaleEggService } from '../../services/sale-egg/sale-egg.service';
import { SaleEgg } from '../../entities/sale-egg';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sale-egg',
  templateUrl: './sale-egg.component.html',
  styleUrls: ['./sale-egg.component.css']
})

export class SaleEggComponent {

  saleEggs:SaleEgg[];
  errorMessage:string;
  loading:boolean;

  constructor(private saleEggService: SaleEggService, private router:Router) {
    this.saleEggs = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.saleEggService.getSaleEggs().subscribe({
      next: (resp) => {
        if (resp) {
          this.saleEggs = resp;
        }

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      }
    });
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  addSale(){
    this.router.navigate(['saleEggAdd']);
  }

}
