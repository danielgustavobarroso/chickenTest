import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseChickenService } from '../../services/purchase-chicken/purchase-chicken.service';
import { PurchaseChicken } from '../../entities/purchase-chicken';
import { Farm } from '../../entities/farm';
import { FarmService } from 'src/app/services/farm/farm.service';

@Component({
  selector: 'app-purchase-chicken-add',
  templateUrl: './purchase-chicken-add.component.html',
  styleUrls: ['./purchase-chicken-add.component.css']
})

export class PurchaseChickenAddComponent {

  purchaseChicken:PurchaseChicken;
  errorMessage:string;
  farms:Farm[];
  moneyAvailable: number;

  constructor(private router:Router, private service:PurchaseChickenService, private farmService:FarmService) {
    this.purchaseChicken = {
      //id: '0',
      farmId: '1',
      purchaseDate: new Date,
      units: 1,
      price: 1,
      totalAmount: 1
    };
    this.errorMessage = '';
    this.farms = [];
    this.moneyAvailable = 0;
    this.getFarms();
  }

  getFarms() {
    this.farmService.getFarms().subscribe({
      next: (resp) => {
        this.farms = resp;
        this.moneyAvailable = this.farms[0].money;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  modifyTotalAmount(){
    this.purchaseChicken.totalAmount = this.purchaseChicken.units * this.purchaseChicken.price;
  }

  savePurchase(){
    //console.log(this.purchaseChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

    if (this.purchaseChicken.totalAmount > this.moneyAvailable) {
      alert('La cantidad de dinero de la venta supera al monto disponible.');
    } else {

      this.service.createPurchaseChicken(this.purchaseChicken).subscribe({
        next: (resp:any) => {
          //console.log(resp);
          if (resp.status == 207) {
            alert(resp.message);
          } else {
            alert("Compra realizada!");
            this.router.navigate(['purchaseChicken']);
          }
          //this.eggs = this.eggs.filter(e => e!==egg);
          //alert("Compra realizada!");
          //this.router.navigate(['purchaseChicken']);
        },
        error: (err) => {
          //this.errorMessage = err.message;
          //if (this.errorMessage != null) {
          //  console.error(err.message);
            alert('Error en la petición:\n\n' + err.message);
          //}
        }
      });
      //console.log('Listo');
    }
  }

  goToPurchaseChickens() {
    this.router.navigate(['purchaseChicken']);
  }

  cleanForm() {
    this.purchaseChicken.purchaseDate=new Date();
    this.purchaseChicken.units=1;
    this.purchaseChicken.price=1;
    this.purchaseChicken.totalAmount=1;
  }

}
