import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseChickenComponent } from './purchase-chicken.component';

describe('PurchaseChickenComponent', () => {
  let component: PurchaseChickenComponent;
  let fixture: ComponentFixture<PurchaseChickenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseChickenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseChickenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
