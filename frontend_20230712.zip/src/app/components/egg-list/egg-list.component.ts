import { Component } from '@angular/core';
import { EggService } from '../../services/egg/egg.service';
import { Egg } from '../../entities/egg';
import { Router } from '@angular/router';

@Component({
  selector: 'app-egg',
  templateUrl: './egg-list.component.html',
  styleUrls: ['./egg-list.component.css']
})
export class EggListComponent {
  eggs:Egg[];
  errorMessage:string;
  loading:boolean;
  eggCount: number;
  states = new Map<String, String>([
    ['A','Disponible'],
    ['D','Descartado'],
    ['S','Vendido'],
    ['C','Convertido en pollo']
  ]);
  origins = new Map<String, String>([
    ['B','Comprado'],
    ['D','Depositado por gallina'],
    ['L', 'Carga inicial']
  ]);

  constructor(private eggService: EggService, private router:Router) {
    this.eggs = [];
    this.errorMessage = '';
    this.loading = true;
    this.eggCount = 0;
  }

  ngOnInit() {
    this.getEggs();
  }

  reload() {
    this.eggs = [];
    this.errorMessage = '';
    this.loading = true;
    this.getEggs();
  }

  getEggs() {
    this.eggService.getEggs().subscribe({
      next: (resp) => {
        this.eggs = resp;
        this.loading = false;
        this.eggCount = this.eggs.length;
      },
      error: (err) => {
        this.errorMessage = err.message;
        /*if (err.error.errorMessage) {
          this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
        }*/
        this.loading = false;
      }
    });
  }

}
