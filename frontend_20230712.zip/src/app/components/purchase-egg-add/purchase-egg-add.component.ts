import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseEggService } from '../../services/purchase-egg/purchase-egg.service';
import { PurchaseEgg } from '../../entities/purchase-egg';
import { Farm } from '../../entities/farm';
import { FarmService } from 'src/app/services/farm/farm.service';
import { Egg } from '../../entities/egg';
import { EggService } from 'src/app/services/egg/egg.service';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-purchase-egg-add',
  templateUrl: './purchase-egg-add.component.html',
  styleUrls: ['./purchase-egg-add.component.css']
})
export class PurchaseEggAddComponent {

  purchaseEgg:PurchaseEgg;
  errorMessage:string;
  farms:Farm[];
  eggs:Egg[];
  moneyAvailable: number;
  unitsAvailable: number;
  eggLimit: number;
  //loginForm: FormGroup;

  constructor(private router:Router, private service:PurchaseEggService, private farmService:FarmService, private eggService:EggService,
    private form:FormBuilder) {
    this.purchaseEgg = {
      //id: '0',
      farmId: '1',
      purchaseDate: new Date,
      units: 1,
      price: 1,
      totalAmount: 1
    };
    this.errorMessage = '';
    this.farms = [];
    this.eggs = [];
    this.moneyAvailable = 0;
    this.unitsAvailable = 0;
    this.eggLimit = 0;
    /*this.loginForm = new FormGroup({
      formUnits: new FormControl(['',[Validators.required],Validators.minLength(5)]),
      formPurchaseDate: new FormControl(''),
      formPrice: new FormControl(''),
      formTotalAmount: new FormControl('')
    });*/
    //=new FormGroup({
    //  units: new FormControl('',Validators.required)
    //});

    this.getFarms();
    this.getEggs();
  }

  getFarms() {
    this.farmService.getFarms().subscribe({
      next: (resp) => {
        this.farms = resp;
        this.moneyAvailable = this.farms[0].money;
        this.eggLimit = this.farms[0].eggLimit;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  getEggs() {
    this.eggService.getEggs().subscribe({
      next: (resp) => {
        //this.chickens = resp;
        this.eggs = resp.filter(e => e.state == 'A');
        this.unitsAvailable = this.eggs.length;
      },
      error: (err) => {
        alert('Error en la petición:\n\n' + err.message);
      }
    });
  }

  modifyTotalAmount(){
    this.purchaseEgg.totalAmount = this.purchaseEgg.units * this.purchaseEgg.price;
  }

  savePurchase(){
    //console.log(this.loginForm.valid);
    //console.log(this.purchaseChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

    if (this.purchaseEgg.totalAmount > this.moneyAvailable) {
      alert('La cantidad de dinero de la venta supera al monto disponible.');
    } else {
      this.service.createPurchaseEgg(this.purchaseEgg).subscribe({
        next: (resp:any) => {
          //console.log(resp);
          if (resp.status == 207) {
            alert(resp.message);
          } else {
            alert("Compra realizada!");
            this.router.navigate(['purchaseEgg']);
          }
          //this.eggs = this.eggs.filter(e => e!==egg);
          //alert("Compra realizada!");
          //this.router.navigate(['purchaseChicken']);
        },
        error: (err) => {
          //this.errorMessage = err.message;
          //if (this.errorMessage != null) {
          //  console.error(err.message);
            alert('Error en la petición:\n\n' + err.message);
          //}
        }
      });
      //console.log('Listo');
    }
  }

  goToPurchaseEggs() {
    this.router.navigate(['purchaseEgg']);
  }

  cleanForm() {
    this.purchaseEgg.purchaseDate=new Date();
    this.purchaseEgg.units=1;
    this.purchaseEgg.price=1;
    this.purchaseEgg.totalAmount=1;
  }

}
