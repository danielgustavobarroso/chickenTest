import { Component } from '@angular/core';
import { PurchaseEggService } from '../../services/purchase-egg/purchase-egg.service';
import { PurchaseEgg } from '../../entities/purchase-egg';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchase-egg',
  templateUrl: './purchase-egg.component.html',
  styleUrls: ['./purchase-egg.component.css']
})
export class PurchaseEggComponent {

  purchaseEggs:PurchaseEgg[];
  errorMessage:string;
  loading:boolean;

  constructor(private purchaseEggService: PurchaseEggService, private router:Router) {
    this.purchaseEggs = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.getPurchaseEggs();
  }

  reloadComponent() {
    this.purchaseEggs = [];
    this.errorMessage = '';
    this.loading = true;
    this.getPurchaseEggs();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  getPurchaseEggs(){
    this.purchaseEggService.getPurchaseEggs().subscribe({
      next: (resp) => {
        //if (response) {
        this.purchaseEggs = resp;
        //}

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        /*this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }*/
        this.errorMessage = err.message;
        /*if (err.error.errorMessage) {
          this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
        }*/
        this.loading = false;
      }
    });
      //this.loading = false;
  }

  addPurchase(){
    this.router.navigate(['purchaseEggAdd']);
  }

}
