import { Component } from '@angular/core';
import { EggService } from '../../../services/egg.service'
import { Router } from '@angular/router';
import { Egg } from '../../../models/egg'

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent {

  //egg:Egg;

  constructor(private service:EggService, private router:Router){
  //  this.egg = new Egg();
  }

  Save(egg:Egg){
    this.service.createEgg(egg).subscribe(
      response => {
        alert("El huevo se cargó con éxito");
        this.router.navigate(['eggs']);
      }
    );
  }
}
