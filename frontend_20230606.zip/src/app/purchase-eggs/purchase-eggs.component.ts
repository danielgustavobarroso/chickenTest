import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-eggs',
  templateUrl: './purchase-eggs.component.html',
  styleUrls: ['./purchase-eggs.component.css']
})
export class PurchaseEggsComponent {

}
