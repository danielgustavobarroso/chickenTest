import { TestBed } from '@angular/core/testing';

import { SaleChickensService } from './sale-chickens.service';

describe('SaleChickensService', () => {
  let service: SaleChickensService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SaleChickensService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
