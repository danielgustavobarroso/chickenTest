export interface Farm {
    id: number,
    name: string,
    money: string,
    chickenLimit: number,
    eggLimit: number
}