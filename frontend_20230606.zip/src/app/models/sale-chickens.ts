export interface SaleChickens {
    id: string,
    farmId: string,
    saleDate: Date,
    units: number,
    price: number,
    totalAmount: number
}