package com.retooling.pursalchi.model;

public class PurchaseChicken {

	
	
}
