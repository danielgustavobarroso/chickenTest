package com.retooling.pursalchi.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.retooling.pursalchi.model.PurchaseChicken;

public interface PurchaseChickenRepository extends MongoRepository<PurchaseChicken, String>{

}
