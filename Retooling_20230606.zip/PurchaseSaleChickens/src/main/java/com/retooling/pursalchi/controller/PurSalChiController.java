package com.retooling.pursalchi.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalchi.model.SaleChicken;
import com.retooling.pursalchi.service.SaleChickenService;
import com.retooling.pursalchi.model.Farm;
import com.retooling.pursalchi.model.Chicken;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class PurSalChiController {

	private static final Logger logger = LoggerFactory.getLogger(PurSalChiController.class);

	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	SaleChickenService saleChickenService;
	
	//Obtener todas las ventas de pollos
	@GetMapping("salechickens")
	public ResponseEntity<List<SaleChicken>> getAllSaleChickens() {
		try {
			logger.info("Invocando getAllSaleChickens...");
			List<SaleChicken> saleChickens = saleChickenService.getAllSaleChickens();
			if (saleChickens.isEmpty())
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(saleChickens, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Guardar una venta de pollos
	@PostMapping("salechickens")
	public ResponseEntity<SaleChicken> createChicken(@RequestBody SaleChicken saleChicken) {
		try {
			logger.info("Invocando createSaleChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
					
			//this.getFarm(saleChicken.getFarmId(), );
			
			List<Chicken> chickens = new ArrayList<Chicken>();
			this.getChickens(saleChicken.getFarmId(), chickens);
			//Chicken[] chickens = new Chicken[](); 
			
			if (saleChicken.getUnits() > chickens.size()) {
				logger.info("La cantidad de pollos que se desea vender es mayor a la disponible");
				return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
			}
			
			for(Chicken chicken: chickens) {
				logger.info("Se elimina pollo por venta: " + chicken);
				this.deleteChicken(chicken.getId());
			}
			
			//saleChicken.getUnits()
			
				return new ResponseEntity<>(saleChickenService.saveSaleChicken(saleChicken), HttpStatus.CREATED);				
			//else
			//	return new ResponseEntity<>(chickenExist.get(), HttpStatus.FOUND);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void getChickens(String id, List<Chicken> chickens) {
		try {
			Chicken[] c = restTemplate.getForObject(urlChicken+"/farms/"+id, Chicken[].class);
			chickens.addAll(Arrays.asList(c));
		} catch (HttpClientErrorException ex) {
			logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	private void deleteChicken(String id) {
		try {
			restTemplate.delete(urlChicken+"/"+id, Chicken.class);
		} catch (HttpClientErrorException ex) {
			logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	
}