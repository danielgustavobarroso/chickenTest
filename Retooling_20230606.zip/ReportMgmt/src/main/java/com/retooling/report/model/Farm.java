package com.retooling.report.model;

public class Farm {
	
	private String id;
	private String name;
	private double money;
	private long chickenLimit;
	private long eggLimit;

	public Farm() {
		super();
	}
	
	public Farm(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public long getChickenLimit() {
		return chickenLimit;
	}

	public void setChickenLimit(long chickenLimit) {
		this.chickenLimit = chickenLimit;
	}

	public long getEggLimit() {
		return eggLimit;
	}

	public void setEggLimit(long eggLimit) {
		this.eggLimit = eggLimit;
	}
	
	@Override
	public String toString() {
		return "Farm [id=" + id + ", name=" + name + ", money=" + money + ", chickenLimit=" + chickenLimit
				+ ", eggLimit=" + eggLimit + "]";
	}

}
