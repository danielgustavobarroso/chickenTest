package com.retooling.chicken.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.retooling.chicken.model.Chicken;

public interface ChickenRepository extends MongoRepository<Chicken, String>{

}
