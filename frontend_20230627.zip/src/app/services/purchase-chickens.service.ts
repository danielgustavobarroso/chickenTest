import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PurchaseChickens } from '../entities/purchase-chickens';

@Injectable({
  providedIn: 'root'
})
export class PurchaseChickensService {

  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = 'http://localhost:8011/pursalchickens-ms/api/v1/purchasechickens';
  }

  getPurchaseChickens() {
    return this.httpClient.get<PurchaseChickens[]>(this.url);
  }

  createPurchaseChickens(purchaseChickens:PurchaseChickens) {
    //console.log('antes');
    return this.httpClient.post<PurchaseChickens>(this.url, purchaseChickens);
  }

}
