import { TestBed } from '@angular/core/testing';

import { PurchaseChickensService } from './purchase-chickens.service';

describe('PurchaseChickensService', () => {
  let service: PurchaseChickensService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PurchaseChickensService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
