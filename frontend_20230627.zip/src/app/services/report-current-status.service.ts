import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CurrentStatusReport } from '../entities/current-status-report';

@Injectable({
  providedIn: 'root'
})
export class ReportCurrentStatusService {

  //se hardcodea con valor 1 para la granja ya que solo se necesita utilizar 1 granja
  private url = 'http://localhost:8011/report-ms/api/v1/reports/currentStatusFarm';

  constructor(private httpClient: HttpClient) { }

  getCurrentStatusFarm(id:string) {
    return this.httpClient.get<CurrentStatusReport>(this.url + "/" + id);
  }

}
