import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseChickensService } from '../../services/purchase-chickens.service';
import { PurchaseChickens } from '../../entities/purchase-chickens';

@Component({
  selector: 'app-purchase-chickens-add',
  templateUrl: './purchase-chickens-add.component.html',
  styleUrls: ['./purchase-chickens-add.component.css']
})

export class PurchaseChickensAddComponent {

  purchaseChicken:PurchaseChickens;

  errorMessage:string;

  constructor(private router:Router, private service:PurchaseChickensService) {
    this.purchaseChicken = {
      //id: '0',
      farmId: '1',
      purchaseDate: new Date,
      units: 0,
      price: 0,
      totalAmount: 0
    };
    this.errorMessage = '';
  }

  Save(){
    console.log(this.purchaseChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

      this.service.createPurchaseChickens(this.purchaseChicken).subscribe({
        next: (response) => {
          //this.eggs = this.eggs.filter(e => e!==egg);
          alert("Compra realizada!");
          this.router.navigate(['purchaseChickens']);
        },
        error: (err) => {
          this.errorMessage = err.message;
          if (this.errorMessage != null) {
            console.error(err.message);
            alert('Error en la petición:\n\n' + err.message);
          }
        }
      });
      //console.log('Listo');
    }

    goToPurchaseChickens() {
      this.router.navigate(['purchaseChickens']);
    }

    modifyTotalAmount(){
      this.purchaseChicken.totalAmount = this.purchaseChicken.units * this.purchaseChicken.price;
    }

}
