import { Component } from '@angular/core';
import { ChickenService } from '../../services/chicken/chicken.service';
import { Chicken } from '../../entities/chicken';
import { Router } from '@angular/router';

@Component({
  selector: 'app-chicken',
  templateUrl: './chicken-list.component.html',
  styleUrls: ['./chicken-list.component.css']
})
export class ChickenListComponent {
  chickens:Chicken[];
  errorMessage:string;
  loading:boolean;

  constructor(private chickenService: ChickenService, private router:Router) {
    this.chickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.getChickens();
  }

  reload() {
    this.chickens = [];
    this.errorMessage = '';
    this.loading = true;
    this.getChickens();
  }

  getChickens() {
    this.chickenService.getChickens().subscribe({
      next: (resp) => {
        this.chickens = resp;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = err.message;
        if (err.error.errorMessage) {
          this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
        }
        this.loading = false;
      }
    });
  }

}
