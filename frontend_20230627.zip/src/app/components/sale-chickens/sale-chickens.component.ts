import { Component } from '@angular/core';
import { SaleChickensService } from '../../services/sale-chickens.service';
import { SaleChickens } from '../../entities/sale-chickens';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sale-chickens',
  templateUrl: './sale-chickens.component.html',
  styleUrls: ['./sale-chickens.component.css']
})

export class SaleChickensComponent {

  saleChickens:SaleChickens[];
  errorMessage:string;
  loading:boolean;

  constructor(private saleChickensService: SaleChickensService, private router:Router) {
    this.saleChickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.saleChickensService.getSaleChickens().subscribe({
      next: (response) => {
        if (response) {
          this.saleChickens = response;
        }

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      }
    });
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  addSale(){
    this.router.navigate(['saleChickensAdd']);
  }

}
