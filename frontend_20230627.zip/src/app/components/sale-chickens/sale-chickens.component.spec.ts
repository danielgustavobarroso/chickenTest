import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleChickensComponent } from './sale-chickens.component';

describe('SaleChickensComponent', () => {
  let component: SaleChickensComponent;
  let fixture: ComponentFixture<SaleChickensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaleChickensComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SaleChickensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
