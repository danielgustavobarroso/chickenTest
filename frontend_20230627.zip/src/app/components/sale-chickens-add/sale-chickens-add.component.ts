import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { SaleChickensService } from '../../services/sale-chickens.service';
import { SaleChickens } from '../../entities/sale-chickens';

@Component({
  selector: 'app-sale-chickens-add',
  templateUrl: './sale-chickens-add.component.html',
  styleUrls: ['./sale-chickens-add.component.css']
})

export class SaleChickensAddComponent {

  saleChicken:SaleChickens;

  errorMessage:string;

  constructor(private router:Router, private service:SaleChickensService) {
    this.saleChicken = {
      //id: '0',
      farmId: '1',
      saleDate: new Date(),
      units: 0,
      price: 0,
      totalAmount: 0
    };
    this.errorMessage = '';
  }

  Save(){
    console.log(this.saleChicken);
    //this.service.createSaleChickens(this.saleChicken);
    //this.router.navigate(['saleChickens']);

      this.service.createSaleChickens(this.saleChicken).subscribe({
        next: (response) => {
          //this.eggs = this.eggs.filter(e => e!==egg);
          alert("Venta realizada!");
          this.router.navigate(['saleChickens']);
        },
        error: (err) => {
          this.errorMessage = err.message;
          if (this.errorMessage != null) {
            console.error(err.message);
            alert('Error en la petición');
          }
        }
      });
      //console.log('Listo');
    }

    goToSaleChickens() {
      this.router.navigate(['saleChickens']);
    }

    modifyTotalAmount(){
      this.saleChicken.totalAmount = this.saleChicken.units * this.saleChicken.price;
    }

}
