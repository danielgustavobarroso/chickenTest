import { Component, OnInit } from '@angular/core';
import { FarmService } from '../../services/farm.service'
import { Farm } from '../../entities/farm'

@Component({
  selector: 'app-farm',
  templateUrl: './farm.component.html',
  styleUrls: ['./farm.component.css']
})

export class FarmComponent {
  farms:Farm[];
  errorMessage:string;
  loading:boolean;

  constructor(private farmService: FarmService) {
    this.farms = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.getFarms();
  }

  reload() {
    this.farms = [];
    this.errorMessage = '';
    this.loading = true;
    this.getFarms();
  }

  getFarms() {
    this.farmService.getFarms().subscribe({
      next: (resp) => {
        this.farms = resp;
        this.loading = false;
      },
      error: (err) => {
        this.errorMessage = err.message;
        this.loading = false;
      }
    });
  }

}
