import { Component } from '@angular/core';
import { PurchaseChickensService } from '../../services/purchase-chickens.service';
import { PurchaseChickens } from '../../entities/purchase-chickens';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchase-chickens',
  templateUrl: './purchase-chickens.component.html',
  styleUrls: ['./purchase-chickens.component.css']
})
export class PurchaseChickensComponent {

  purchaseChickens:PurchaseChickens[];
  errorMessage:string;
  loading:boolean;

  constructor(private purchaseChickensService: PurchaseChickensService, private router:Router) {
    this.purchaseChickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.purchaseChickensService.getPurchaseChickens().subscribe({
      next: (response) => {
        if (response) {
          this.purchaseChickens = response;
        }

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      }
    });
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  addPurchase(){
    this.router.navigate(['purchaseChickensAdd']);
  }

}
