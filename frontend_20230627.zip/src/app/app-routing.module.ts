import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FarmComponent } from './components/farm/farm.component';
import { ChickenListComponent } from './components/chicken-list/chicken-list.component';
import { EggListComponent } from './components/egg-list/egg-list.component';
//import { ReportComponent } from './components/report/report.component';
import { ReportCurrentStatusComponent } from './components/report-current-status/report-current-status.component';
//import { AddComponent } from  './components/egg/add/add.component';
import { SaleChickensComponent } from './components/sale-chickens/sale-chickens.component';
import { SaleChickensAddComponent }  from './components/sale-chickens-add/sale-chickens-add.component';
import { PurchaseChickensComponent } from './components/purchase-chickens/purchase-chickens.component';
import { PurchaseChickensAddComponent } from './components/purchase-chickens-add/purchase-chickens-add.component';

const routes: Routes = [
  {path:'', redirectTo: 'reportCurrentStatus', pathMatch: 'full'},
  {path: 'farm', component: FarmComponent},
  {path: 'chicken', component: ChickenListComponent},
  {path: 'egg', component: EggListComponent},
  //{path: 'addEgg', component: AddComponent},
  //{path: 'reports', component: ReportComponent},
  {path: 'reportCurrentStatus', component: ReportCurrentStatusComponent},
  {path: 'saleChicken', component: SaleChickensComponent},
  {path: 'saleChickenAdd', component: SaleChickensAddComponent},
  {path: 'purchaseChicken', component: PurchaseChickensComponent},
  {path: 'purchaseChickenAdd', component: PurchaseChickensAddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
