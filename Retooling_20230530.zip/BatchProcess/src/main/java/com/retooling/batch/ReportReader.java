package com.retooling.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import com.retooling.batch.model.CurrentStatusFarm;

public class ReportReader implements ItemReader<CurrentStatusFarm> {

	private static final Logger logger = LoggerFactory.getLogger(ReportReader.class);
	
	private CurrentStatusFarm currentStatusFarm;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${api.microservice.report}")
	private String url;
	
	public ReportReader() {
		initialize();
	}
	
	@Override
	public CurrentStatusFarm read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
	
		logger.info("Leyendo la información del reporte...");
		
		if (CurrentStatusFarmNotInitialized()) {
			//Devuelve datos de la granja con id = 1
			currentStatusFarm = restTemplate.getForObject(url+"1", CurrentStatusFarm.class);
		}
		
		// TODO Auto-generated method stub
		return currentStatusFarm;
	/*} catch (HttpClientErrorException ex) {
		currentStatusFarm.setStatusFarm(ex.getStatusCode().toString());
		logger.error("Exception :: ", ex);
	} catch (Exception ex) {
		currentStatusFarm.setStatusFarm("Error inesperado");
		logger.error("Exception :: ", ex);
		//e.printStackTrace();
	}*/
	}
	
	private boolean CurrentStatusFarmNotInitialized() {
		return this.currentStatusFarm == null;
	}
	
	private initialize() {
		
	}

}
