package com.retooling.batch.model;

public class CurrentStatusFarm {
	
	private String farmId;
	private String farmName;
	private double farmMoney;
	private long chickenLimit;
	private long eggLimit;
	private long eggsCount;
	private long chickensCount;
	private String statusFarm;
	private String statusEggs;
	private String statusChickens;

	public CurrentStatusFarm() {
		super();
	}

	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}
	
	public String getFarmName() {
		return farmName;
	}

	public void setFarmName(String farmName) {
		this.farmName = farmName;
	}
	
	public double getFarmMoney() {
		return farmMoney;
	}

	public void setFarmMoney(double farmMoney) {
		this.farmMoney = farmMoney;
	}

	public long getChickenLimit() {
		return chickenLimit;
	}

	public void setChickenLimit(long chickenLimit) {
		this.chickenLimit = chickenLimit;
	}

	public long getEggLimit() {
		return eggLimit;
	}

	public void setEggLimit(long eggLimit) {
		this.eggLimit = eggLimit;
	}
	
	public long getEggsCount() {
		return eggsCount;
	}

	public void setEggsCount(long eggsCount) {
		this.eggsCount = eggsCount;
	}

	public long getChickensCount() {
		return chickensCount;
	}

	public void setChickensCount(long chickensCount) {
		this.chickensCount = chickensCount;
	}

	public String getStatusFarm() {
		return statusFarm;
	}

	public void setStatusFarm(String statusFarm) {
		this.statusFarm = statusFarm;
	}

	public String getStatusEggs() {
		return statusEggs;
	}

	public void setStatusEggs(String statusEggs) {
		this.statusEggs = statusEggs;
	}

	public String getStatusChickens() {
		return statusChickens;
	}

	public void setStatusChickens(String statusChickens) {
		this.statusChickens = statusChickens;
	}

	@Override
	public String toString() {
		return "CurrentStatusFarm [farmId=" + farmId + ", farmName=" + farmName + ", farmMoney=" + farmMoney
				+ ", eggsCount=" + eggsCount + ", chickensCount=" + chickensCount + ", statusFarm=" + statusFarm
				+ ", statusEggs=" + statusEggs + ", statusChickens=" + statusChickens + "]";
	}

}
