package com.retooling.batch;

import org.springframework.batch.item.ItemProcessor;

import com.retooling.batch.model.CurrentStatusFarm;

public class ReportProcessor implements ItemProcessor<CurrentStatusFarm, CurrentStatusFarm>{

	@Override
	public CurrentStatusFarm process(CurrentStatusFarm item) throws Exception {
		
		if ((item.getEggsCount() == item.getEggLimit()) || (item.getChickensCount() == item.getChickenLimit())) {
			return item;
		} else {
			return null;	
		}
	}
	
}
