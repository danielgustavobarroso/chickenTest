package com.retooling.chicken.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import com.retooling.chicken.controller.ChickenController;
import com.retooling.chicken.model.Chicken;
import com.retooling.chicken.repository.ChickenRepository;
import com.retooling.chicken.service.ChickenService;

@Service
public class ChickenServiceImpl implements ChickenService {

	private static final Logger logger = LoggerFactory.getLogger(ChickenServiceImpl.class);
	
	@Autowired
	ChickenRepository chickenRepository;

	@Autowired
	MongoTemplate mongoTemplate;
	
	public List<Chicken> getAllChickens() {
		logger.info("Invocando getAllChickens...");
		return chickenRepository.findAll();			
	}

	public Optional<Chicken> getChickenById(String id) {
		logger.info("Invocando getChickenById...");
		return chickenRepository.findById(id);			
	}
	
	public Chicken saveChicken(Chicken chicken) {
		logger.info("Invocando saveChicken...");
		return chickenRepository.save(chicken);
	}

	public void updateChicken(Chicken chicken) {
		logger.info("Invocando updateChicken...");
		chickenRepository.save(chicken);
	}
	
	public void deleteChicken(String id) {
		logger.info("Invocando deleteChicken...");
		chickenRepository.deleteById(id);
	}
	
	public List<Chicken> getChickensByFarmId(String idFarm) {
		logger.info("Invocando getChickensByFarmId...");
		Query query = new Query();
		query.addCriteria(Criteria.where("farmId").is(idFarm));
		List<Chicken> eggs = mongoTemplate.find(query, Chicken.class);
		return eggs;
	}
	
}
