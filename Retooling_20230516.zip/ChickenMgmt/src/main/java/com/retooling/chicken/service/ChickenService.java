package com.retooling.chicken.service;

import java.util.List;
import java.util.Optional;

import com.retooling.chicken.model.Chicken;

public interface ChickenService {
	
	public List<Chicken> getAllChickens();

	public Optional<Chicken> getChickenById(String id);
	
	public Chicken saveChicken(Chicken chicken);

	public void updateChicken(Chicken chicken);
	
	public void deleteChicken(String id);
	
	public List<Chicken> getChickensByFarmId(String idFarm);
	
}
