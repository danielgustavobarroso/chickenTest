import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})

export class ReportService {

 // private url = 'http://localhost:8011/ms-report/api/v1/reports/currentStatusFarm/1';

  constructor(private httpClient: HttpClient) { }

 /* getCurrentStatusFarm() {
    return this.httpClient.get(this.url);
  }*/

}
