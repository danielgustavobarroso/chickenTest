export interface CurrentStatusReport {
    farmId: string,
	farmName: string,
	farmMoney: number,
	chickenLimit: number,
	eggLimit: number,
	eggsCount: number,
	chickensCount: number
}
