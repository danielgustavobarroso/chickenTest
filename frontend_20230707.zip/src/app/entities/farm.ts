export interface Farm {
    id: number,
    name: string,
    money: number,
    chickenLimit: number,
    eggLimit: number
}