import { Component } from '@angular/core';
import { ReportCurrentStatusService } from '../../services/report-current/report-current-status.service';
import { Router } from '@angular/router';
import { CurrentStatusReport } from '../../entities/current-status-report';

@Component({
  selector: 'app-report-current-status',
  templateUrl: './report-current-status.component.html',
  styleUrls: ['./report-current-status.component.css']
})
export class ReportCurrentStatusComponent {

  report:CurrentStatusReport;
  errorMessage:string;
  loading:boolean;
  farmId:string;

  constructor(private currentStatusService: ReportCurrentStatusService, private router:Router) {
    this.report = {
      farmId: '',
      farmName: '',
      farmMoney: 0,
      chickenLimit: 0,
      eggLimit: 0,
      eggsCount: 0,
      chickensCount: 0
    };
    this.errorMessage = '';
    this.loading = true;
    //se asigna 1 porque va a utilizar una unica granja con ese id
    this.farmId = '1';
  }

  ngOnInit() {
    this.getCurrentStatusReport();
  }

  reload() {
    this.report = {
      farmId: '',
      farmName: '',
      farmMoney: 0,
      chickenLimit: 0,
      eggLimit: 0,
      eggsCount: 0,
      chickensCount: 0
    };
    this.errorMessage = '';
    this.loading = true;
    this.getCurrentStatusReport();
  }

  getCurrentStatusReport() {
    this.currentStatusService.getCurrentStatusFarm(this.farmId).subscribe({
      next: (resp) => {
        this.report = resp;
        this.loading = false;
      },
      error: (err) => {
        console.log(err);
        this.errorMessage = err.message;
        if (err.error.errorMessage) {
          this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
        }
        this.loading = false;
      }
    });
  }

}
