import { Component } from '@angular/core';
import { PurchaseChickenService } from '../../services/purchase-chicken/purchase-chicken.service';
import { PurchaseChicken } from '../../entities/purchase-chicken';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchase-chicken',
  templateUrl: './purchase-chicken.component.html',
  styleUrls: ['./purchase-chicken.component.css']
})
export class PurchaseChickenComponent {

  purchaseChickens:PurchaseChicken[];
  errorMessage:string;
  loading:boolean;

  constructor(private purchaseChickenService: PurchaseChickenService, private router:Router) {
    this.purchaseChickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.getPurchaseChickens();
  }

  reloadComponent() {
    this.purchaseChickens = [];
    this.errorMessage = '';
    this.loading = true;
    this.getPurchaseChickens();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  getPurchaseChickens(){
    this.purchaseChickenService.getPurchaseChickens().subscribe({
      next: (resp) => {
        //if (response) {
        this.purchaseChickens = resp;
        //}

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        /*this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }*/
        this.errorMessage = err.message;
        /*if (err.error.errorMessage) {
          this.errorMessage = this.errorMessage + ' [Más detalles: ' + err.error.errorMessage + ']';
        }*/
        this.loading = false;
      }
    });
      //this.loading = false;
  }

  addPurchase(){
    this.router.navigate(['purchaseChickenAdd']);
  }

}
