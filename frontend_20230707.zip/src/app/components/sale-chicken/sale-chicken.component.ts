import { Component } from '@angular/core';
import { SaleChickenService } from '../../services/sale-chicken/sale-chicken.service';
import { SaleChicken } from '../../entities/sale-chicken';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sale-chicken',
  templateUrl: './sale-chicken.component.html',
  styleUrls: ['./sale-chicken.component.css']
})

export class SaleChickenComponent {

  saleChickens:SaleChicken[];
  errorMessage:string;
  loading:boolean;

  constructor(private saleChickenService: SaleChickenService, private router:Router) {
    this.saleChickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.saleChickenService.getSaleChickens().subscribe({
      next: (response) => {
        if (response) {
          this.saleChickens = response;
        }

        //console.log(this.saleChickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      error: (err) => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      }
    });
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  addSale(){
    this.router.navigate(['saleChickenAdd']);
  }

}
