import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-egg',
  templateUrl: './purchase-egg.component.html',
  styleUrls: ['./purchase-egg.component.css']
})
export class PurchaseEggComponent {

}
