import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FarmComponent } from './components/farm/farm.component';
import { ChickenListComponent } from './components/chicken-list/chicken-list.component';
import { EggListComponent } from './components/egg-list/egg-list.component';
//import { ReportComponent } from './components/report/report.component';
import { ReportCurrentStatusComponent } from './components/report-current-status/report-current-status.component';
//import { AddComponent } from  './components/egg/add/add.component';
import { SaleChickenComponent } from './components/sale-chicken/sale-chicken.component';
import { SaleChickenAddComponent }  from './components/sale-chicken-add/sale-chicken-add.component';
import { PurchaseChickenComponent } from './components/purchase-chicken/purchase-chicken.component';
import { PurchaseChickenAddComponent } from './components/purchase-chicken-add/purchase-chicken-add.component';
import { WelcomeComponent } from './components/welcome/welcome.component';

const routes: Routes = [
  {path:'', redirectTo: 'welcome', pathMatch: 'full'},
  {path: 'welcome', component: WelcomeComponent},
  {path: 'farm', component: FarmComponent},
  {path: 'chicken', component: ChickenListComponent},
  {path: 'egg', component: EggListComponent},
  //{path: 'addEgg', component: AddComponent},
  //{path: 'reports', component: ReportComponent},
  {path: 'reportCurrentStatus', component: ReportCurrentStatusComponent},
  {path: 'saleChicken', component: SaleChickenComponent},
  {path: 'saleChickenAdd', component: SaleChickenAddComponent},
  {path: 'purchaseChicken', component: PurchaseChickenComponent},
  {path: 'purchaseChickenAdd', component: PurchaseChickenAddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
