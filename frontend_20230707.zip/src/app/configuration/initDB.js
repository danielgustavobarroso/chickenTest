/*
 * Script que se encarga de poblar la base de datos
 * Comando para su ejecucion: npm run load
 * Autor: Daniel Barroso
 */

print("STARTING SCRIPT");
//Host donde está nuestra base de datos, no tiene que ser nuestro equipo local, puede ser cualquier mongoDb.
conn = new Mongo("localhost");
//Nombre de la base de datos que vamos a utilizar
db = conn.getDB("chickenTest");

/*Limpiamos la base de datos por si existia algo antes*/
db.dropDatabase();

/*coleciones de nuestro modelo de datos*/
db.createCollection("farms");
db.createCollection("eggs");
db.createCollection("chickens");

/* Farms */
print("***********creating farms*********");

farm1 = { 
"_id" : "1",
"name" : "Los Cuñados",
"money" : 200000,
"chickenLimit": 10,
"eggLimit": 20
}

print("***********creating eggs*********");

/* Eggs */
egg1 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-03T00:00:00Z"),
    "origin": "C"
};

egg2 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-04T00:00:00Z"),
    "origin": "C"
};

egg3 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-05T00:00:00Z"),
    "origin": "C"
};

egg4 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-06T00:00:00Z"),
    "origin": "C"
};

egg5 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-07T00:00:00Z"),
    "origin": "C"
};

print("***********creating chickens*********");

/* Chickens */
chicken1 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-05T00:00:00Z"),
    "origin": "C"
};

chicken2 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-06T00:00:00Z"),
    "origin": "C"
};

chicken3 = {
    "farmId" : "1",
    "state" : "D",
    "creationDate" : new Date("2023-07-07T00:00:00Z"),
    "origin": "C"
};


print("***********saving farms*********");
db.farms.save(farm1);

print("***********saving eggs*********");
db.eggs.save(egg1);
db.eggs.save(egg2);
db.eggs.save(egg3);
db.eggs.save(egg4);
db.eggs.save(egg5);

print("***********saving chickens*********");
db.chickens.save(chicken1);
db.chickens.save(chicken2);
db.chickens.save(chicken3);

print("SCRIPT FINISHED");
