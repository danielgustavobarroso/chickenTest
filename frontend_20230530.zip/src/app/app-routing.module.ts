import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FarmComponent } from './components/farm/farm.component';
import { ChickenComponent } from './components/chicken/chicken.component';
import { EggComponent } from './components/egg/egg.component';
import { ReportComponent } from './components/report/report.component';
import { ReportCurrentStatusComponent } from './components/report-current-status/report-current-status.component';

const routes: Routes = [
  {path:'', redirectTo: 'reportCurrentStatus', pathMatch: 'full'},
  {path: 'farms', component: FarmComponent},
  {path: 'chickens', component: ChickenComponent},
  {path: 'eggs', component: EggComponent},
  {path: 'reports', component: ReportComponent},
  {path: 'reportCurrentStatus', component: ReportCurrentStatusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
