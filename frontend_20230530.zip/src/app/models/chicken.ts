export interface Chicken {
    id: string,
    farmId: string
}