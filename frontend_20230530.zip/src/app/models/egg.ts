export interface Egg {
    id: string,
    farmId: string
}