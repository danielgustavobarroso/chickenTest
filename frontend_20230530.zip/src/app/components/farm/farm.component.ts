import { Component, OnInit } from '@angular/core';
import { FarmService } from '../../services/farm.service'
import { Farm } from '../../models/farm'

@Component({
  selector: 'app-farm',
  templateUrl: './farm.component.html',
  styleUrls: ['./farm.component.css']
})

export class FarmComponent {
  farms:Farm[];
  //farms:any;
//  isFetching:boolean = false;
  errorMessage:string = '';
  loading:boolean = true;

  constructor(private farmService: FarmService) {
    this.farms = [];
    this.loading = true;
  }

  ngOnInit() {
    //this.isFetching = true;
    this.farmService.getFarms().subscribe(
      response => {
        console.log(response);
      //  this.isFetching = false;
        this.farms = response;
        //console.log("Servicio Farm - Ok");
        if (!this.farms){
          alert('Error en el servidor');
        } else {
          this.loading = false;
        }
      },
      err => {
        //this.isFetching = false;
        this.errorMessage = err.message;
        //console.error("Servicio Farm - Error");
        if (this.errorMessage != null) {
          console.log(err.message);
          alert('Error en la petición');
        }
      })
  }

}
