package com.retooling.chicken.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retooling.chicken.model.Chicken;
import com.retooling.chicken.service.ChickenService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class ChickenController {
	
	private static final Logger logger = LoggerFactory.getLogger(ChickenController.class);
	
	@Autowired
	ChickenService chickenService;
	
	//Obtener todos los pollos
	@GetMapping("chickens")
	public ResponseEntity<List<Chicken>> getAllChickens() {
		try {
			logger.info("Invocando getAllChickens...");
			List<Chicken> chickens = chickenService.getAllChickens();
			if (chickens.isEmpty())
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(chickens, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Obtener un pollo por id
	@GetMapping("chickens/{id}")
	public ResponseEntity<Chicken> getChickenById(@PathVariable("id") String id) {
		try {
			logger.info("Invocando getChickenById con id...");
			Optional<Chicken> chicken = chickenService.getChickenById(id); 
			if (chicken.isEmpty())
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);				
			else
				return new ResponseEntity<>(chicken.get(), HttpStatus.OK);				
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//Guardar un pollo
	@PostMapping("chickens")
	public ResponseEntity<Chicken> createChicken(@RequestBody Chicken chicken) {
		try {
			logger.info("Invocando createChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
				return new ResponseEntity<>(chickenService.saveChicken(chicken), HttpStatus.CREATED);				
			//else
			//	return new ResponseEntity<>(chickenExist.get(), HttpStatus.FOUND);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Actualizar datos de un pollo
	@PutMapping("chickens")
	public ResponseEntity<Chicken> updateChicken(@RequestBody Chicken chickenUpdated) {
		try {
			logger.info("Invocando updateChicken...");
			Optional<Chicken> chicken = chickenService.getChickenById(chickenUpdated.getId());
			if (chicken.isEmpty()) {
				return new ResponseEntity<> (null, HttpStatus.NOT_FOUND);
			} else {
				chickenService.updateChicken(chickenUpdated);
				return new ResponseEntity<>(null, HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	//Borrar un pollo
	@DeleteMapping("chickens/{id}")
	public ResponseEntity<Chicken> deleteChicken(@PathVariable("id") String id){
		try {
			logger.info("Invocando deleteChicken...");
			Optional<Chicken> chicken = chickenService.getChickenById(id);
			if (chicken.isEmpty()) {
				return new ResponseEntity<> (null, HttpStatus.NOT_FOUND);
			} else {
				chickenService.deleteChicken(id);
				return new ResponseEntity<> (null, HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Obtener pollos por id de granja
	@GetMapping("chickens/farms/{id}")
	public ResponseEntity<List<Chicken>> getChickensByFarmId(@PathVariable("id") String id) {
		try {
			logger.info("Invocando getChickensByFarmId...");
			List<Chicken> chickens = chickenService.getChickensByFarmId(id); 
			if (chickens.isEmpty())
				return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);				
			else
				return new ResponseEntity<>(chickens, HttpStatus.OK);				
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}