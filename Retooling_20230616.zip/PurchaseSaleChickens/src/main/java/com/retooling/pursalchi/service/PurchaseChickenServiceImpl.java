package com.retooling.pursalchi.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import com.retooling.pursalchi.model.PurchaseChicken;
import com.retooling.pursalchi.repository.PurchaseChickenRepository;

@Service
public class PurchaseChickenServiceImpl implements PurchaseChickenService {

	private static final Logger logger = LoggerFactory.getLogger(PurchaseChickenServiceImpl.class);
	
	@Autowired
	PurchaseChickenRepository purchaseChickenRepository;

	@Autowired
	MongoTemplate mongoTemplate;
	
	public List<PurchaseChicken> getAllPurchaseChickens() {
		logger.info("Invocando getPurchaseAllChickens...");
		return purchaseChickenRepository.findAll();			
	}

	public Optional<PurchaseChicken> getPurchaseChickenById(String id) {
		logger.info("Invocando getPurchaseChickenById...");
		return purchaseChickenRepository.findById(id);			
	}
	
	public PurchaseChicken savePurchaseChicken(PurchaseChicken purchaseChicken) {
		logger.info("Invocando saveSaleChicken...");
		return purchaseChickenRepository.save(purchaseChicken);
	}

	public void updatePurchaseChicken(PurchaseChicken purchaseChicken) {
		logger.info("Invocando updatePurchaseChicken...");
		purchaseChickenRepository.save(purchaseChicken);
	}
	
	public void deletePurchaseChicken(String id) {
		logger.info("Invocando deletePurchaseChicken...");
		purchaseChickenRepository.deleteById(id);
	}
	
}
