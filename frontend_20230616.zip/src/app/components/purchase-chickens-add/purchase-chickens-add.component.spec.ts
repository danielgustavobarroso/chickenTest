import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseChickensAddComponent } from './purchase-chickens-add.component';

describe('PurchaseChickensAddComponent', () => {
  let component: PurchaseChickensAddComponent;
  let fixture: ComponentFixture<PurchaseChickensAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseChickensAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseChickensAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
