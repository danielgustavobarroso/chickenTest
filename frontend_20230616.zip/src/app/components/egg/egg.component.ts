import { Component } from '@angular/core';
import { EggService } from '../../services/egg.service';
import { Egg } from '../../models/egg';
import { Router } from '@angular/router';

@Component({
  selector: 'app-egg',
  templateUrl: './egg.component.html',
  styleUrls: ['./egg.component.css']
})
export class EggComponent {
  eggs:Egg[];
  errorMessage:string;
  loading:boolean;

  constructor(private eggService: EggService, private router:Router) {
    this.eggs = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.eggService.getEggs().subscribe(
      response => {
        if (response) {
          this.eggs = response;
        }

        //console.log(this.eggs);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      err => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      })
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  Add() {
    this.router.navigate(['addEgg']);
  }

  Delete(egg:Egg) {
    this.eggService.deleteEgg(egg.id).subscribe(
      response => {
        this.eggs = this.eggs.filter(e => e!==egg);
        alert("Huevo eliminado!");
      },
      err => {
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          alert('Error en la petición');
        }
      })
  }

}
