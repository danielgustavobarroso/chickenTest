import { Component } from '@angular/core';
import { ChickenService } from '../../services/chicken.service';
import { Chicken } from '../../models/chicken';
import { Router } from '@angular/router';

@Component({
  selector: 'app-chicken',
  templateUrl: './chicken.component.html',
  styleUrls: ['./chicken.component.css']
})
export class ChickenComponent {
  chickens:Chicken[];
  errorMessage:string;
  loading:boolean;

  constructor(private chickenService: ChickenService, private router:Router) {
    this.chickens = [];
    this.errorMessage = '';
    this.loading = true;
  }

  ngOnInit() {
    this.chickenService.getEggs().subscribe(
      response => {
        if (response) {
          this.chickens = response;
        }

        //console.log(this.chickens);
        /*if (!this.eggs){
          alert('Error en el servidor');
        }*/
        //this.loading = false;
        /*} else {
          this.loading = false;
        }*/
        this.loading = false;
      },
      err => {
        //console.log(this.eggs.length);
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          //alert('Error en la petición');
          this.loading = false;
        }

      })
      //this.loading = false;
  }

  reloadComponent() {
    this.ngOnInit();
    //console.log('Hola');
    //this.router.navigate([this.router.url]);
  }

  Add() {
    this.router.navigate(['addEgg']);
  }

  Delete(chicken:Chicken) {
    this.chickenService.deleteEgg(chicken.id).subscribe(
      response => {
        this.chickens = this.chickens.filter(e => e!==chicken);
        alert("Huevo eliminado!");
      },
      err => {
        this.errorMessage = err.message;
        if (this.errorMessage != null) {
          console.error(err.message);
          alert('Error en la petición');
        }
      })
  }

}
