import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PurchaseChickensComponent } from './purchase-chickens.component';

describe('PurchaseChickensComponent', () => {
  let component: PurchaseChickensComponent;
  let fixture: ComponentFixture<PurchaseChickensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PurchaseChickensComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PurchaseChickensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
