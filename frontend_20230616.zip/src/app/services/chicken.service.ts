import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Chicken } from '../models/chicken';

@Injectable({
  providedIn: 'root'
})
export class ChickenService {

  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = 'http://localhost:8011/chicken-ms/api/v1/chickens';
  }

  getEggs() {
    return this.httpClient.get<Chicken[]>(this.url);
  }

  deleteEgg(id:string) {
    return this.httpClient.delete<Chicken>(this.url + "/" + id);
  }

  createEgg(chicken:Chicken){
    return this.httpClient.post<Chicken>(this.url,chicken);
  }

}
