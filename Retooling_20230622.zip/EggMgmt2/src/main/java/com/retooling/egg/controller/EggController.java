package com.retooling.egg.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retooling.egg.EggMgmtApplication;
import com.retooling.egg.entity.Egg;
import com.retooling.egg.exception.EggNotFoundException;
import com.retooling.egg.service.EggService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class EggController {

	private static final Logger logger = LoggerFactory.getLogger(EggController.class);
	
	@Autowired
	EggService service;
	
	//Obtener todas los huevos
	@GetMapping("eggs")
	public ResponseEntity<List<Egg>> getAllEggs() {
		logger.info("Controller - Calling method getAllEggs...");
		return new ResponseEntity<>(service.getAllEggs(), HttpStatus.OK);
	}

	//Obtener un huevo por id
	@GetMapping("eggs/{id}")
	public ResponseEntity<Egg> getEggById(@PathVariable("id") String id) throws EggNotFoundException {
		logger.info("Controller - Calling method getEggById con id=" + id);
		return new ResponseEntity<>(service.getEggById(id), HttpStatus.OK);				
	}
	
	//Guardar un huevo
	@PostMapping("eggs")
	public ResponseEntity<Egg> createEgg(@RequestBody Egg egg) {
		logger.info("Controller - Calling method createEgg...");
		return new ResponseEntity<>(service.saveEgg(egg), HttpStatus.CREATED);				
	}

	//Actualizar datos de un huevo
	@PutMapping("eggs")
	public ResponseEntity<Egg> updateEgg(@RequestBody Egg eggUpdated) throws EggNotFoundException {
		logger.info("Controller - Calling method updateEgg...");
		Egg egg = service.getEggById(eggUpdated.getId());
		egg.setFarmId(eggUpdated.getFarmId());
		egg.setId(eggUpdated.getId());
		return new ResponseEntity<>(service.saveEgg(egg), HttpStatus.OK);
	}
	
	//Borrar un huevo
	@DeleteMapping("eggs/{id}")
	public ResponseEntity<Egg> deleteEgg(@PathVariable("id") String id) throws EggNotFoundException{
		logger.info("Controller - Calling method deleteEgg...");
		Egg egg = service.getEggById(id);
		service.deleteEgg(egg);
		return new ResponseEntity<>(egg, HttpStatus.OK);
	}
	
	//Obtener huevos por id de granja
	@GetMapping("eggs/farms/{id}")
	public ResponseEntity<List<Egg>> getEggsByFarmId(@PathVariable("id") String id) throws EggNotFoundException {
		logger.info("Controller - Calling method getEggsByFarmId..."); 
		return new ResponseEntity<>(service.getEggsByFarmId(id), HttpStatus.OK);				
	}
	
}