package com.retooling.chicken.exception;

public class ChickenNotFoundException extends Exception {

	public ChickenNotFoundException(String message) {
		super(message);
	}
	
}
