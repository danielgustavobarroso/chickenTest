package com.retooling.chicken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChickenMgmtAppTests {

	@Test
	void contextLoads() {
	}

}
