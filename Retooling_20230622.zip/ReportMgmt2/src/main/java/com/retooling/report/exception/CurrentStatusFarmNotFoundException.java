package com.retooling.report.exception;

public class CurrentStatusFarmNotFoundException extends Exception {

	public CurrentStatusFarmNotFoundException(String message) {
		super(message);
	}
	
}
