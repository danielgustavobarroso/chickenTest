package com.retooling.report.service;

import com.retooling.report.exception.CurrentStatusFarmNotFoundException;
import com.retooling.report.model.CurrentStatusFarm;

public interface ReportService {

	public CurrentStatusFarm getCurrentStatusFarm(String id) throws CurrentStatusFarmNotFoundException;
	
}
