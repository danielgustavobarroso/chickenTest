package com.retooling.report.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.report.model.CurrentStatusFarm;
import com.retooling.report.model.Egg;
import com.retooling.report.model.Farm;
//import com.retooling.chicken.exception.ChickenNotFoundException;
import com.retooling.report.exception.CurrentStatusFarmNotFoundException;
import com.retooling.report.model.Chicken;

@Service
public class ReportServiceImpl implements ReportService {

	private static final Logger logger = LoggerFactory.getLogger(ReportServiceImpl.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
	/*@Value("${api.microservice.farm}")
	private String urlFarm;
	*/
	@Value("${api.microservice.egg}")
	private String urlEgg;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	@Autowired
	private ApiCall apiCall;
	
	public CurrentStatusFarm getCurrentStatusFarm(String id) throws CurrentStatusFarmNotFoundException {
		logger.info("Iniciando servicio getCurrentStatusFarm...");
		CurrentStatusFarm currentStatusFarm = new CurrentStatusFarm();
		
		Farm farm;
		try {
			farm = apiCall.getFarm(id);
		} catch (Exception ex) {
			throw new CurrentStatusFarmNotFoundException(ex.getMessage());
		}

		List<Egg> eggs;
		try {
			eggs = apiCall.getEggs(id);
		} catch (HttpClientErrorException.NotFound ex) {
			eggs = new ArrayList<>();
		} catch (Exception ex) {
			throw new CurrentStatusFarmNotFoundException(ex.getMessage());
		}
				
		List<Chicken> chickens;
		try {
			chickens = apiCall.getChickens(id);
		} catch (HttpClientErrorException.NotFound ex) {
			chickens = new ArrayList<>();
		} catch (Exception ex) {
			throw new CurrentStatusFarmNotFoundException(ex.getMessage());
		}

		currentStatusFarm.setFarmId(farm.getId());
		currentStatusFarm.setFarmName(farm.getName());
		currentStatusFarm.setFarmMoney(farm.getMoney());
		currentStatusFarm.setChickenLimit(farm.getChickenLimit());
		currentStatusFarm.setEggLimit(farm.getEggLimit());
		currentStatusFarm.setEggsCount(eggs.size());
		currentStatusFarm.setChickensCount(chickens.size());		
		return currentStatusFarm;
	}
}
