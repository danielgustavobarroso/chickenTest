package com.retooling.pursalchi.service;

import java.util.List;
import java.util.Optional;

import com.retooling.pursalchi.entity.PurchaseChicken;

public interface PurchaseChickenService {
	
	public List<PurchaseChicken> getAllPurchaseChickens();

	public Optional<PurchaseChicken> getPurchaseChickenById(String id);
	
	public PurchaseChicken savePurchaseChicken(PurchaseChicken purchaseChicken);

	public void updatePurchaseChicken(PurchaseChicken purchaseChicken);
	
	public void deletePurchaseChicken(String id);
	
}
