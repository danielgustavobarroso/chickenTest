package com.retooling.pursalchi.service;

import java.util.List;
import java.util.Optional;

import com.retooling.pursalchi.entity.SaleChicken;

public interface SaleChickenService {
	
	public List<SaleChicken> getAllSaleChickens();

	public Optional<SaleChicken> getSaleChickenById(String id);
	
	public SaleChicken saveSaleChicken(SaleChicken saleChicken);

	public void updateSaleChicken(SaleChicken saleChicken);
	
	public void deleteSaleChicken(String id);
	
}
