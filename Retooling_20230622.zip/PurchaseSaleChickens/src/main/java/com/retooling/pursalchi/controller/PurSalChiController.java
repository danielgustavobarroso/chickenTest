package com.retooling.pursalchi.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.retooling.pursalchi.entity.Chicken;
import com.retooling.pursalchi.entity.Farm;
import com.retooling.pursalchi.entity.PurchaseChicken;
import com.retooling.pursalchi.entity.SaleChicken;
import com.retooling.pursalchi.service.PurchaseChickenService;
import com.retooling.pursalchi.service.SaleChickenService;

@RestController
@RequestMapping("/api/v1")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "*")
public class PurSalChiController {

	private static final Logger logger = LoggerFactory.getLogger(PurSalChiController.class);

	@Value("${api.microservice.farm}")
	private String urlFarm;
	
	@Value("${api.microservice.chicken}")
	private String urlChicken;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	SaleChickenService saleChickenService;

	@Autowired
	PurchaseChickenService purchaseChickenService;
	
	//Obtener todas las ventas de pollos
	@GetMapping("salechickens")
	public ResponseEntity<List<SaleChicken>> getAllSaleChickens() {
		try {
			logger.info("Invocando getAllSaleChickens...");
			List<SaleChicken> saleChickens = saleChickenService.getAllSaleChickens();
			if (saleChickens.isEmpty())
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(saleChickens, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Guardar una venta de pollos
	@PostMapping("salechickens")
	public ResponseEntity<SaleChicken> createSaleChicken(@RequestBody SaleChicken saleChicken) {
		try {
			logger.info("Invocando createSaleChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
					
			//this.getFarm(saleChicken.getFarmId(), );
			
			List<Chicken> chickens = new ArrayList<Chicken>();
			this.getChickens(saleChicken.getFarmId(), chickens);
			//Chicken[] chickens = new Chicken[](); 
			
			if (saleChicken.getUnits() > chickens.size()) {
				logger.info("La cantidad de pollos que se desea vender es mayor a la disponible");
				return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
			}
			
			for(int indice=0;indice<saleChicken.getUnits();indice++) {
				this.deleteChicken(chickens.get(indice).getId());		
				logger.info("Venta - Se elimina pollo con id [" + chickens.get(indice).getId() + "]");
			}
			
			return new ResponseEntity<>(saleChickenService.saveSaleChicken(saleChicken), HttpStatus.CREATED);
			
			/*for(Chicken chicken: chickens) {
				logger.info("Se elimina pollo por venta: " + chicken);
				this.deleteChicken(chicken.getId());
			}*/
			
			//Se realiza este cambio para asignar ObjectId de MongoDB
			/*if ("0".equals(saleChicken.getId())) {
				saleChicken.setId(null);
			}*/
			
			//saleChicken.getUnits()
			
				//return new ResponseEntity<>(saleChickenService.saveSaleChicken(saleChicken), HttpStatus.CREATED);				
			//else
			//	return new ResponseEntity<>(chickenExist.get(), HttpStatus.FOUND);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Obtener todas las compras de pollos
	@GetMapping("purchasechickens")
	public ResponseEntity<List<PurchaseChicken>> getAllPurchaseChickens() {
		try {
			logger.info("Invocando getAllPurchaseChickens...");
			List<PurchaseChicken> purchaseChickens = purchaseChickenService.getAllPurchaseChickens();
			if (purchaseChickens.isEmpty())
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			else
				return new ResponseEntity<>(purchaseChickens, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//Guardar una compra de pollos
	/*@PostMapping("purchasechickens")
	public ResponseEntity<PurchaseChicken> createPurchaseChicken(@RequestBody PurchaseChicken purchaseChicken) {
		try {
			logger.info("Invocando createPurchaseChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
			
			Farm farm = new Farm();
			this.getFarm(purchaseChicken.getFarmId(), farm);
						
			if (purchaseChicken.getTotalAmount() > farm.getMoney()) {
				logger.info("La cantidad de dinero utilizada supera el monto disponible.");
				return new ResponseEntity<>(null, HttpStatus.NOT_ACCEPTABLE);
			}

			//List<Chicken> chickens = new ArrayList<Chicken>();
			//this.getChickens(purchaseChicken.getFarmId(), chickens);
			//Chicken[] chickens = new Chicken[](); 
			
			for(int indice=0;indice<purchaseChicken.getUnits();indice++) {
				Chicken chicken = new Chicken();
				chicken.setFarmId("1");
				chicken = this.addChicken(chicken);
				logger.info("Compra - Se agrega pollo: [" + chicken.getId() + "]");
			}
			
			return new ResponseEntity<>(purchaseChickenService.savePurchaseChicken(purchaseChicken), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}*/

	private void getFarm(String id, Farm farm) {
		try {
			Farm f = restTemplate.getForObject(urlFarm+"/"+id, Farm.class);
			farm.setId(f.getId());
			farm.setName(f.getName());
			farm.setMoney(f.getMoney());
			farm.setChickenLimit(f.getChickenLimit());
			farm.setEggLimit(f.getEggLimit());
		//} catch (HttpClientErrorException ex) {
			//currentStatusFarm.setStatusFarm(ex.getStatusCode().toString());
			//logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}
	
	private void getChickens(String id, List<Chicken> chickens) {
		try {
			Chicken[] c = restTemplate.getForObject(urlChicken+"/farms/"+id, Chicken[].class);
			chickens.addAll(Arrays.asList(c));
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}

	private Chicken addChicken(Chicken chicken) {
		try {
			return restTemplate.postForObject(urlChicken, chicken, Chicken.class);
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			return null;
			//e.printStackTrace();
		}
	}
	
	private void deleteChicken(String id) {
		try {
			restTemplate.delete(urlChicken+"/"+id, Chicken.class);
		//} catch (HttpClientErrorException ex) {
		//	logger.error("Exception :: ", ex);
		} catch (Exception ex) {
			logger.error("Exception :: ", ex);
			//e.printStackTrace();
		}
	}

//************************************************************
	
	//Guardar una compra de pollos
	@PostMapping("purchasechickens")
	public ResponseEntity<?> createPurchaseChicken(@RequestBody PurchaseChicken purchaseChicken) {
		Map<String, Object> map = new LinkedHashMap<String,Object>();
		try {
			
			logger.info("Invocando createPurchaseChicken...");
			//Optional<Chicken> chickenExist = chickenService.getChickenById(chicken.getId()); 
			//if (chickenExist.isEmpty())
			
			Farm farm = restTemplate.getForObject(urlFarm+"/"+purchaseChicken.getFarmId(), Farm.class);
			/*Farm farm = null;
			try {
				farm = restTemplate.getForObject(urlFarm+"/"+purchaseChicken.getFarmId(), Farm.class);
			}catch (HttpClientErrorException ex) {
				map.clear();
				map.put("status", 0);
				map.put("message", "Error al buscar datos de granja con id = [" + purchaseChicken.getFarmId() + "]");
				logger.info("Error al buscar datos de granja con id = [" + purchaseChicken.getFarmId() + "]");
				return new ResponseEntity<>(map, HttpStatus.NOT_FOUND);
			}*/
					
			if (purchaseChicken.getTotalAmount() > farm.getMoney()) {
				map.clear();
				map.put("status", 0);
				map.put("message", "La cantidad de dinero utilizada supera el monto disponible.");
				logger.info("La cantidad de dinero utilizada supera el monto disponible.");
				return new ResponseEntity<>(map, HttpStatus.EXPECTATION_FAILED);
			}

			farm.setMoney(farm.getMoney() - purchaseChicken.getTotalAmount());
			restTemplate.put(urlFarm, farm, Farm.class);
			
			//List<Chicken> chickens = new ArrayList<Chicken>();
			//this.getChickens(purchaseChicken.getFarmId(), chickens);
			//Chicken[] chickens = new Chicken[](); 
			
			for(int indice=0;indice<purchaseChicken.getUnits();indice++) {
				Chicken chicken = new Chicken();
				chicken.setFarmId(purchaseChicken.getFarmId());
				chicken = restTemplate.postForObject(urlChicken, chicken, Chicken.class);
				logger.info("Compra - Se agrega pollo: [" + chicken.getId() + "]");
			}
			
			return new ResponseEntity<>(purchaseChickenService.savePurchaseChicken(purchaseChicken), HttpStatus.CREATED);
		} catch (Exception e) {
			map.clear();
			map.put("status", 0);
			map.put("message", e.getMessage()); 
			logger.error("Exception :: ", e);
			return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}