package com.retooling.pursalchi.entity;

public class Chicken {
	
	private String id;
	private String farmId;

	public Chicken() {
		super();
	}
	
	public Chicken(String id, String farmId) {
		super();
		this.id = id;
		this.farmId = farmId;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getFarmId() {
		return farmId;
	}

	public void setFarmId(String farmId) {
		this.farmId = farmId;
	}

	@Override
	public String toString() {
		return "Chicken [id=" + id + ", farmId=" + farmId + "]";
	}
	
}
